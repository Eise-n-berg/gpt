"""V5: repair veranda enclosure and refine the reference house. Load V4 comparison.
All changes are editable geometry/materials; V4 and the original house stay intact.
"""
import bpy,bmesh,ast,math,random,json,sys
from pathlib import Path
from mathutils import Vector
from math import sin,cos,pi
root=Path(__file__).resolve().parent;out=root/'v5';out.mkdir(exist_ok=True)
scene=bpy.context.scene;random.seed(198005)
asset=bpy.data.collections['V4 • REFERENCE HOUSE / complete asset'];asset.name='V5 • REFERENCE HOUSE / complete asset'
anchor=bpy.data.objects['NEW HOUSE • origin / ground centre']
parts={c.name.split(' • ',1)[1]:c for c in asset.children}
col=parts['06 verandas and entrances']
source=ast.parse((root/'age_soviet_1980.py').read_text());names={'nodeset','node','mathnode','vector','noise','ramp','mix','bump','finish'}
exec(compile(ast.Module(body=[x for x in source.body if isinstance(x,ast.FunctionDef) and x.name in names],type_ignores=[]),'material_helpers','exec'))
source=ast.parse((root/'build_reference_house_v4.py').read_text());names={'mesh','cube','beam','curve','ico','face_point','face_cube','face_curve','sheet_roof'}
exec(compile(ast.Module(body=[x for x in source.body if isinstance(x,ast.FunctionDef) and x.name in names],type_ignores=[]),'house_helpers','exec'))
timber=bpy.data.materials['V4 • grey-brown weathered logs'];green=bpy.data.materials['V4 • faded sage-green paint'];white=bpy.data.materials['V4 • chalky white carved wood'];plank=bpy.data.materials['V4 • unpainted annex boards']
slate=bpy.data.materials['V4 • aged fibre-cement slate / lichen and soot'];iron=next(m for m in bpy.data.materials if m.name.startswith('V3 • old hardware'));stone=next(m for m in bpy.data.materials if m.name.startswith('STONE •'));dark=bpy.data.materials['V4 • deep window recess and chinking']
def principled(m):return next(n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED')

# Paint keeps its colour but now has local losses, chalking and distinct board ages.
for material,pigment,exposed in [(green,(.073,.16,.094),(.075,.068,.047)),(white,(.48,.49,.405),(.11,.093,.064))]:
    material.name=material.name.replace('V4','V5',1);n=material.node_tree.nodes;l=material.node_tree.links;p=principled(material)
    tex=next(x for x in n if x.type=='TEX_IMAGE' and 'paint_mask' in x.image.name)
    lower=.62 if material==white else .42
    mask=ramp(n,l,tex.outputs['Color'],[(.05,(lower,lower,lower)),(.42,(1,1,1))],'Local paint loss, rather than a flat pigment layer')
    info=node(n,'ShaderNodeObjectInfo','Boards painted and repaired at different times')
    variation=ramp(n,l,info.outputs['Random'],[(0,(.72,.75,.68)),(1,(1.14,1.12,1.02))])
    paint=mix(n,l,pigment,variation,mode='MULTIPLY')
    g=node(n,'ShaderNodeNewGeometry','Physical weathering');rain=noise(n,l,vector(n,l,g.outputs['Position'],(6,6,.55)),1,3,'Narrow runoff marks')
    paint=mix(n,l,paint,ramp(n,l,rain,[(.25,(.63,.67,.58)),(.75,(1,1,1))]),.4,mode='MULTIPLY')
    l.new(mix(n,l,exposed,paint,mask),p.inputs['Base Color']);p.inputs['Roughness'].default_value=.9
    # Replace excessively corrugated paint relief with a thin chipped film.
    old=p.inputs['Normal'].links[0].from_socket
    l.new(bump(n,l,mask,.00045,.45,old),p.inputs['Normal'])
    for bu in n:
        if bu.type=='BUMP' and bu.inputs['Distance'].default_value>.004:
            bu.inputs['Distance'].default_value=.002 if material==white else .003
            bu.inputs['Strength'].default_value=.35

# Quieter brown-grey timber, so the broad grain no longer looks like marbling.
timber.name=timber.name.replace('V4','V5',1);n=timber.node_tree.nodes;l=timber.node_tree.links;p=principled(timber)
old=p.inputs['Base Color'].links[0].from_socket
l.new(mix(n,l,old,(.082,.068,.047),.42),p.inputs['Base Color'])
info=node(n,'ShaderNodeObjectInfo','Natural course-to-course differences');old=p.inputs['Base Color'].links[0].from_socket
l.new(mix(n,l,old,ramp(n,l,info.outputs['Random'],[(0,(.73,.72,.66)),(1,(1.08,1.06,.97))]),mode='MULTIPLY'),p.inputs['Base Color'])

# Old fibre-cement is grey, with restrained runoff and rare lichen; never metallic.
slate.name=slate.name.replace('V4','V5',1);n=slate.node_tree.nodes;l=slate.node_tree.links;p=principled(slate)
g=node(n,'ShaderNodeNewGeometry','Slate weathering / metres');v=g.outputs['Position']
cloud=noise(n,l,v,2.1,3,'Slow uneven exposure')
base=ramp(n,l,cloud,[(.2,(.060,.064,.057)),(.5,(.145,.151,.136)),(.8,(.235,.241,.215))])
rain=noise(n,l,vector(n,l,v,(.8,14,2)),1,3,'Runoff follows roof pitch')
base=mix(n,l,base,ramp(n,l,rain,[(.18,(.55,.59,.51)),(.8,(1.04,1.04,.99))]),.5,mode='MULTIPLY')
info=node(n,'ShaderNodeObjectInfo','Age difference between overlapping sheets')
base=mix(n,l,base,ramp(n,l,info.outputs['Random'],[(0,(.81,.83,.78)),(1,(1.10,1.09,1.03))]),mode='MULTIPLY')
lichen=noise(n,l,v,23,2,'Sparse pale lichen');mask=ramp(n,l,lichen,[(.68,(0,0,0)),(.80,(.50,.50,.50))])
l.new(mix(n,l,base,(.14,.15,.09),mask),p.inputs['Base Color']);p.inputs['Roughness'].default_value=.94

# Brick hue, mortar and soot vary at the scale of real individual bricks.
brick=bpy.data.materials['V4 • old red clay brick'];brick.name=brick.name.replace('V4','V5',1)
n=brick.node_tree.nodes;l=brick.node_tree.links;p=principled(brick);g=node(n,'ShaderNodeNewGeometry','Brick pores and soot');v=g.outputs['Position']
no=noise(n,l,v,34,3,'Fired clay');base=ramp(n,l,no,[(.2,(.105,.039,.018)),(.8,(.28,.12,.055))])
info=node(n,'ShaderNodeObjectInfo','Different firing');base=mix(n,l,base,ramp(n,l,info.outputs['Random'],[(0,(.68,.63,.57)),(1,(1.14,1.04,.93))]),mode='MULTIPLY')
z=node(n,'ShaderNodeSeparateXYZ','Soot at chimney mouth');l.new(v,z.inputs[0]);height=mathnode(n,l,'MULTIPLY',mathnode(n,l,'SUBTRACT',z.outputs['Z'],5.36),1/.49);soot=ramp(n,l,height,[(0,(1,1,1)),(1,(.38,.37,.34))])
l.new(mix(n,l,base,soot,mode='MULTIPLY'),p.inputs['Base Color']);l.new(bump(n,l,no,.002,.45),p.inputs['Normal'])
for o in asset.all_objects:
    if o.name.startswith('NEW • chimney face brick') or o.name.startswith('NEW • chimney side brick'):
        o.location.z+=random.uniform(-.002,.002)

# Delete the incomplete porch assembly, including its original unsupported glass edges.
removed=[]
for o in list(asset.all_objects):
    if o.name.startswith(('NEW • veranda','NEW • glass porch')):
        removed.append(o.name);bpy.data.objects.remove(o,do_unlink=True)
col=parts['06 verandas and entrances']
def skin(name,xa,xb,ya,yb,zbottom,ztop_a,ztop_b,mat):
    # A solid prism with top height varying in X, for the wall under a lean-to roof.
    return mesh(name,[(xa,ya,zbottom),(xb,ya,zbottom),(xb,yb,zbottom),(xa,yb,zbottom),(xa,ya,ztop_a),(xb,ya,ztop_b),(xb,yb,ztop_b),(xa,yb,ztop_a)],[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],mat)
def roof_z(x):return 3.035-(x-2.96)*.18
cube('V5 porch stone plinth',(3.72,-1.43,.38),(1.58,2.65,.30),stone,.035)
cube('V5 porch sealed floor',(3.71,-1.43,.57),(1.51,2.56,.12),plank,.008)
for y in [-2.67,-.16]:
    # Continuous upper wedge touches the underside of the slope, with no open band.
    skin('V5 porch continuous sloped head wall',2.98,4.46,y-.045,y+.045,2.48,roof_z(2.98)-.012,roof_z(4.46)-.012,green)
skin('V5 porch east head wall',4.38,4.47,-2.71,-.12,2.48,roof_z(4.38)-.012,roof_z(4.47)-.012,green)
# The back of the veranda faces the storage shed and is entirely clad.
cube('V5 porch closed back wall',(3.72,-.16,1.54),(1.50,.09,1.90),plank,.008)
for i in range(10):cube('V5 porch front lower cladding',(3.00+(i+.5)*1.44/10,-2.67,.88),(.139,.085,.61),green,.005)
for i in range(16):cube('V5 porch side lower cladding',(4.43,-2.67+(i+.5)*2.50/16,.88),(.085,.15,.61),green,.005)
cube('V5 porch continuous front lining',(3.72,-2.625,.88),(1.50,.045,.67),plank)
cube('V5 porch continuous side lining',(4.395,-1.415,.88),(.05,2.59,.67),plank)
for x,y in [(3.01,-2.67),(4.43,-2.67),(4.43,-.16)]:
    cube('V5 porch full corner post',(x,y,(.57+roof_z(x))*.5),(.13,.13,roof_z(x)-.57),green,.008)
# Continuous sill/belt ties the glazing into the panelled wall.
cube('V5 porch front sill',(3.72,-2.70,1.19),(1.53,.14,.085),white,.007)
cube('V5 porch east sill',(4.46,-1.43,1.19),(.14,2.57,.085),white,.007)

glass=bpy.data.materials['V4 • old window glass'];glass.name='V5 • main window glass';p=principled(glass);p.inputs['Emission Strength'].default_value=.28;p.inputs['Roughness'].default_value=.27
linen=bpy.data.materials['V4 • curtain cotton'];linen.name='V5 • curtain cotton';principled(linen).inputs['Emission Strength'].default_value=.22
porchglass=glass.copy();porchglass.name='V5 • porch glass / individual rebated panes';p=principled(porchglass);p.inputs['Base Color'].default_value=(.105,.135,.123,1);p.inputs['Transmission Weight'].default_value=.28;p.inputs['Roughness'].default_value=.22;p.inputs['IOR'].default_value=1.47;p.inputs['Emission Strength'].default_value=.08
def glazed(center,theta,w,h,ncols,nrows):
    # Outer casing, sash, individual glass solids and overlapping rebates.
    for u in [-w/2,w/2]:face_cube('V5 porch structural glazing jamb',center,theta,u,.025,0,.085,.10,h+.10,green,.005)
    for z in [-h/2,h/2]:face_cube('V5 porch structural glazing head or sill',center,theta,0,.025,z,w+.085,.10,.085,green,.005)
    for i in range(ncols+1):face_cube('V5 porch white sash upright',center,theta,-w/2+i*w/ncols,.09,0,.031,.055,h,white,.003)
    for j in range(nrows+1):face_cube('V5 porch white sash rail',center,theta,0,.09,-h/2+j*h/nrows,w,.055,.031,white,.003)
    for i in range(ncols):
        for j in range(nrows):
            u=-w/2+(i+.5)*w/ncols;z=-h/2+(j+.5)*h/nrows
            face_cube('V5 porch rebated glass pane',center,theta,u,.065,z,w/ncols+.009,.008,h/nrows+.009,porchglass,.001)
    # A recessed curtain at each side, leaving the centre darker and reflective.
    for sign in [-1,1]:
        for i in range(6):face_cube('V5 porch recessed curtain pleat',center,theta,sign*(w/2-.08-i*.022),-.05+.007*sin(i*2),0,.025,.012,h-.07,linen,.002)
glazed((3.72,-2.675,1.84),0,1.27,1.25,4,3)
glazed((4.435,-1.84,1.84),pi/2,1.38,1.25,4,3)
# Vertical infill closes the corner and the gap between side glazing and the door.
for ya,yb in [(-2.67,-2.53),(-1.15,-.96)]:cube('V5 porch side glazing infill',(4.43,(ya+yb)/2,1.84),(.09,yb-ya+.02,1.31),green,.005)
for xa,xb in [(2.98,3.085),(4.355,4.47)]:cube('V5 porch front glazing infill',((xa+xb)/2,-2.67,1.84),(xb-xa+.015,.09,1.31),green,.005)
cube('V5 porch solid door leaf',(4.435,-.555,1.56),(.055,.80,1.98),green,.005)
for i in range(5):cube('V5 porch entrance door board',(4.45,-.89+(i+.5)*.71/5,1.50),(.085,.137,1.78),green,.005)
for y in [-.95,-.16]:cube('V5 porch door casing',(4.49,y,1.53),(.105,.085,1.99),white,.006)
cube('V5 porch door lintel',(4.49,-.555,2.52),(.105,.88,.085),white,.006)
beam('V5 porch iron latch',(4.52,-.80,1.43),(4.52,-.80,1.57),.014,iron,8)
for i in range(3):cube('V5 porch access step',(4.70+i*.23,-.53,.40-i*.11),(.28,1.02,.13),plank,.012)
# Continuous roof substrate and ceiling. Overlapping sheets sit above it.
skin('V5 porch roof substrate',2.94,4.64,-2.89,.05,2.60,roof_z(2.94)-.035,roof_z(4.64)-.035,dark)
# Replace the prism bottom with a thin sloped ceiling, rather than a deep visible wedge.
o=bpy.data.objects['NEW • V5 porch roof substrate']
for i in range(4):o.data.vertices[i].co.z=o.data.vertices[i+4].co.z-.035
before=set(col.objects);sheet_roof('V5 porch corrugated slate',-2.89,.05,2.94,4.64,roof_z(2.94),roof_z(4.64),slate,2)
for o in set(col.objects)-before:
    for v in o.data.vertices:v.co.x,v.co.y=v.co.y,-v.co.x-2.84
for y in [-2.88,.05]:beam('V5 porch roof edge board',(2.96,y,roof_z(2.96)-.01),(4.63,y,roof_z(4.63)-.01),.045,plank,4)
cube('V5 porch eave fascia',(4.61,-1.42,roof_z(4.61)-.025),(.08,3.0,.12),green,.007)
# A subdued lamp illuminates the enclosed veranda instead of uniformly glowing panes.
d=bpy.data.lights.new('NEW • V5 enclosed porch lamp','POINT');d.energy=22;d.color=(1,.64,.34);d.shadow_soft_size=.15;o=bpy.data.objects.new(d.name,d);col.objects.link(o);o.parent=anchor;o.location=(3.64,-1.43,2.56)

# Close the underside of the main roof and give the corrugated sheets real thickness.
col=parts['04 corrugated slate and chimney']
for o in asset.all_objects:
    if o.name.startswith(('NEW • overlapping corrugated slate','NEW • V5 porch corrugated slate')):
        m=o.modifiers.new('Fibre cement sheet / 6mm thickness','SOLIDIFY');m.thickness=.006;m.offset=-1
for sign in [-1,1]:
    vs=[(0,-3.25,5.245),(sign*3.39,-3.25,3.38),(sign*3.39,3.25,3.38),(0,3.25,5.245)]
    mesh('V5 continuous dark roof underlay',vs,[(0,1,2,3)],dark)
# Flashing follows the actual slope beneath the chimney.
mesh('V5 chimney apron flashing',[(x,y,5.30-x*(1.85/3.38)+.025) for x,y in [(.31,-.12),(.96,-.12),(.96,.52),(.31,.52)]],[(0,1,2,3)],iron)

# Carved panels with broader relief read as woodwork rather than thin bent wire.
col=parts['05 carved windows and shutters']
for center,theta in [((-1.85,-2.9,1.82),0),((0,-2.9,1.82),0),((1.85,-2.9,1.82),0),((.47,2.9,1.88),pi),((3,1.05,1.88),pi/2),((-3,1.08,1.88),-pi/2)]:
    for sign in [-1,1]:
        # Filled tapered leaf on either side of the central crown.
        pts=[(sign*.06,.223,.865),(sign*.20,.223,.84),(sign*.39,.223,.815),(sign*.45,.223,.845),(sign*.25,.223,.89),(sign*.11,.223,.94)]
        o=mesh('V5 carved pediment leaf',[face_point(center,theta,*p) for p in pts],[(0,1,2,3,4,5)],white)
        mod=o.modifiers.new('Carved wooden relief','SOLIDIFY');mod.thickness=.018
    # Small rosette, rounded carved bosses and a scalloped lower apron.
    face_curve('V5 carved central diamond',center,theta,[(0,.24,.99),(-.055,.24,.925),(0,.24,.87),(.055,.24,.925),(0,.24,.99)],.017,white)
    for u in [-.39,0,.39]:
        o=ico('V5 carved rosette',face_point(center,theta,u,.245,.83),(.028,.018,.028),white,2)
    face_cube('V5 carved apron board',center,theta,0,.18,-.76,.98,.055,.09,white,.006)
    for i in range(7):
        u=-.42+i*.14
        face_curve('V5 carved apron scallop',center,theta,[(u-.06,.222,-.80),(u-.03,.222,-.85),(u+.03,.222,-.85),(u+.06,.222,-.80)],.013,white)

# Subtle physical splits on the exposed log faces, kept out of window openings.
col=parts['02 log walls'];checkmat=dark
for k in range(14):
    z=.68+k*.205
    for j in range(5):
        x=random.uniform(-2.85,2.45);length=random.uniform(.16,.46)
        if 1.0<z<2.65 and any(x-.07<cx+.60 and x+length+.07>cx-.60 for cx in [-1.85,0,1.85]):continue
        dz=random.uniform(-.050,.050);yy=-2.9-math.sqrt(.119**2-dz**2)-.001
        curve('V5 longitudinal timber check',[(x+length*i/5,yy,z+dz+random.uniform(-.0015,.0015)) for i in range(6)],.0012,checkmat)

# A few loose autumn leaves sit around the plinth and barrel, not in window joins.
col=parts['08 house props'];leafm=[m for m in bpy.data.materials if m.name.startswith('LEAF •')]
for material in leafm:
    vs=[];fs=[]
    for j in range(30):
        x=random.uniform(-3.4,4.8);y=random.choice([random.uniform(-3.5,-3.13),random.uniform(3.3,3.7)])
        z=.10;r=random.uniform(.025,.055);a=random.uniform(0,2*pi);u=Vector((r*cos(a),r*sin(a),0));v=Vector((-r*.5*sin(a),r*.5*cos(a),.008));p=Vector((x,y,z));k=len(vs)
        vs.extend([tuple(p-u),tuple(p+v),tuple(p+u),tuple(p-v)]);fs.append((k,k+1,k+2,k+3))
    mesh('V5 fallen leaves beside plinth',vs,fs,material)

# Rust has flakes and runoff, rather than one uniform red cylinder.
rust=bpy.data.materials['V4 • rusted rain barrel'];rust.name=rust.name.replace('V4','V5',1)
n=rust.node_tree.nodes;l=rust.node_tree.links;p=principled(rust);g=node(n,'ShaderNodeNewGeometry','Steel barrel rust scale');v=g.outputs['Position']
coarse=noise(n,l,vector(n,l,v,(6,6,1.3)),2,3,'Vertical rust runoff');fine=noise(n,l,v,140,2,'Flaking oxide')
base=ramp(n,l,coarse,[(.2,(.024,.021,.016)),(.5,(.095,.043,.020)),(.8,(.20,.09,.028))]);l.new(base,p.inputs['Base Color']);l.new(bump(n,l,fine,.0014,.4),p.inputs['Normal']);p.inputs['Roughness'].default_value=.9

# Uneven stones and small hardware help break the repeated shapes.
col=parts['01 foundation'];stone_copy=stone.copy();stone_copy.name='V5 • individually weathered plinth stones'
n=stone_copy.node_tree.nodes;l=stone_copy.node_tree.links;p=principled(stone_copy);old=p.inputs['Base Color'].links[0].from_socket;info=node(n,'ShaderNodeObjectInfo','Different fieldstones')
l.new(mix(n,l,old,ramp(n,l,info.outputs['Random'],[(0,(.62,.64,.57)),(1,(1.06,1.06,.97))]),mode='MULTIPLY'),p.inputs['Base Color'])
for o in asset.all_objects:
    if o.name.startswith('NEW • stone plinth'):
        for slot in o.material_slots:
            if slot.material==stone:slot.material=stone_copy
        for vert in o.data.vertices:
            vert.co.x+=random.uniform(-.007,.007);vert.co.y+=random.uniform(-.006,.006);vert.co.z+=random.uniform(-.006,.006)
col=parts['05 carved windows and shutters']
for x in [-1.85,0,1.85]:
    for sign in [-1,1]:
        for z in [1.31,2.33]:beam('V5 shutter square nail',(x+sign*.72,-3.065,z),(x+sign*.72,-3.075,z),.009,iron,8)

# Optional low autumn planting echoes the yellow foliage at the reference plinth.
planting=bpy.data.collections.new('NEW HOUSE • 09 optional autumn planting');asset.children.link(planting);col=planting
gold=[]
for i,c in enumerate([(.17,.115,.026),(.29,.19,.033),(.11,.13,.040)]):
    m,n,l,p=nodeset('V5 • autumn plinth foliage '+str(i));p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=.92;gold.append(m)
for bx,by,sz in [(-2.65,-3.14,.75),(-1.15,-3.18,.6),(1.08,-3.15,.6),(2.55,-3.15,.8),(4.76,-2.45,.65)]:
    for j in range(11):
        a=random.random()*2*pi;h=random.uniform(.25,.7)*sz;r=random.uniform(.06,.25)*sz
        start=Vector((bx,by,.10));tip=start+Vector((r*cos(a),r*sin(a),h));beam('V5 autumn fine stem',start,tip,.003,plank,5)
        vs=[];fs=[]
        for k in range(10):
            t=random.uniform(.3,1);p=start.lerp(tip,t)+Vector((random.uniform(-.10,.10),random.uniform(-.08,.08),0));r=random.uniform(.018,.038);a=random.random()*2*pi
            u=Vector((r*cos(a),r*sin(a),.006));v=Vector((-r*.55*sin(a),r*.55*cos(a),.008));idx=len(vs);vs.extend([tuple(p-u),tuple(p+v),tuple(p+u),tuple(p-v)]);fs.append((idx,idx+1,idx+2,idx+3))
        mesh('V5 sparse yellow autumn leaves',vs,fs,random.choice(gold))

scene.camera=bpy.data.objects['V4 • 01 / neighbouring houses'];scene['version']='V5 / sealed veranda and reference visual refinement'
scene['veranda_repair']='Continuous head walls, infill jambs, rebates, floor and sloped ceiling; no unsupported glazing gaps.'
scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.render.resolution_x=1600;scene.render.resolution_y=1000
bpy.ops.wm.save_as_mainfile(filepath=str(out/'two_houses_comparison_v5.blend'))
(out/'repair_info.json').write_text(json.dumps({'removed_v4_porch_objects':len(removed),'asset_objects':len(asset.all_objects),'porch_top_glazing_z':2.465,'porch_closed_header_bottom_z':2.48,'header_overlap_sash_m':.0275},indent=2))
print('V5_SCENE_READY',flush=True)
