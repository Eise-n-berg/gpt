import bpy,sys
from pathlib import Path
s=bpy.context.scene;out=Path(bpy.data.filepath).parent
s.cycles.use_denoising=False;s.cycles.adaptive_threshold=.025
preview='--preview' in sys.argv
if 'comparison' in bpy.data.filepath:
    shots=[('01_comparison','V4 • 01 / neighbouring houses',1600,1000)]
else:
    shots=[('02_asset_daylight','ASSET • front and veranda',1440,1100),('03_veranda_closeup','ASSET • veranda inspection',1440,1152),('04_front_reference','ASSET • low front reference',1440,1100)]
    if preview:shots=shots[:2]
for name,cam,w,h in shots:
    s.camera=bpy.data.objects[cam];s.cycles.samples=16 if preview else 48 if name in ['02_asset_daylight','03_veranda_closeup'] else 32
    s.render.resolution_x=960 if preview else w;s.render.resolution_y=int(h*960/w) if preview else h;s.render.resolution_percentage=100
    s.render.filepath=str(out/(('preview_' if preview else '')+name+'_raw.png'))
    bpy.ops.render.render(write_still=True);print('V5_RENDER_READY',name,flush=True)
