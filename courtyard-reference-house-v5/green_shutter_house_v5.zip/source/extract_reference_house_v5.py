"""Standalone V5 scene, reusing the established neutral studio arrangement."""
import bpy,sys
from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'extract_reference_house_v4.py').read_text()
source=source.replace('V4 • REFERENCE HOUSE','V5 • REFERENCE HOUSE').replace("for name in ['V4 • old window glass','V4 • curtain cotton']:","for name in ['V5 • main window glass','V5 • curtain cotton','V5 • porch glass / individual rebated panes']:")
source=source.replace('green_shutter_house_asset.blend','green_shutter_house_v5.blend').replace('V4_STANDALONE_READY','V5_STANDALONE_READY').replace("'04_asset_daylight_raw.png'","'02_asset_daylight_raw.png'")
exec(compile(source,str(root/'extract_reference_house_v4.py'),'exec'))
s=bpy.context.scene
# Retain the V4 studio camera for a fair comparison and add close diagnostic views.
camera('ASSET • veranda inspection',(8,-9,4.8),(3.55,-1.55,1.92),4.5)
camera('ASSET • veranda side',(11,-1.6,2.3),(3.6,-1.6,1.9),3.8)
camera('ASSET • low front reference',(7,-18,6.2),(0,0,2.7),11.2)
s['version']='V5 / sealed veranda and material refinement';s['asset_note']=s['asset_note'].replace('V4','V5')
bpy.ops.wm.save_as_mainfile(filepath=str(out/'green_shutter_house_v5.blend'))
