"""Blender compositor: exact 1% mix of a block-pixelated render.
Install make_pixel_group() after the final image node in a 3D scene to reuse.
No image regeneration, geometry or material changes.
"""
import bpy,json
from pathlib import Path
root=Path(__file__).resolve().parent;source=root.parent/'v5'
def make_pixel_group():
    group=bpy.data.node_groups.new('Pixelation • adjustable 1 percent','CompositorNodeTree')
    group.interface.new_socket(name='Image',in_out='INPUT',socket_type='NodeSocketColor')
    strength=group.interface.new_socket(name='Strength',in_out='INPUT',socket_type='NodeSocketFloat');strength.default_value=.01;strength.min_value=0;strength.max_value=1
    block=group.interface.new_socket(name='Block pixels',in_out='INPUT',socket_type='NodeSocketFloat');block.default_value=14;block.min_value=1;block.max_value=64
    group.interface.new_socket(name='Image',in_out='OUTPUT',socket_type='NodeSocketColor')
    n=group.nodes;l=group.links;i=n.new('NodeGroupInput');i.location=(-650,100);o=n.new('NodeGroupOutput');o.location=(550,100)
    reciprocal=n.new('CompositorNodeMath');reciprocal.operation='DIVIDE';reciprocal.inputs[0].default_value=1;reciprocal.location=(-650,-180);l.new(i.outputs['Block pixels'],reciprocal.inputs[1])
    down=n.new('CompositorNodeScale');down.space='RELATIVE';down.label='Downsample';down.location=(-400,0);l.new(i.outputs['Image'],down.inputs['Image']);l.new(reciprocal.outputs[0],down.inputs['X']);l.new(reciprocal.outputs[0],down.inputs['Y'])
    pixel=n.new('CompositorNodePixelate');pixel.location=(-150,0);pixel.label='Square pixels / nearest sampling';l.new(down.outputs[0],pixel.inputs[0])
    up=n.new('CompositorNodeScale');up.space='RELATIVE';up.location=(30,0);l.new(pixel.outputs[0],up.inputs[0]);l.new(i.outputs['Block pixels'],up.inputs['X']);l.new(i.outputs['Block pixels'],up.inputs['Y'])
    mix=n.new('CompositorNodeMixRGB');mix.blend_type='MIX';mix.label='99% original + 1% pixelated';mix.location=(300,100);l.new(i.outputs['Strength'],mix.inputs[0]);l.new(i.outputs['Image'],mix.inputs[1]);l.new(up.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],o.inputs[0])
    group['formula']='output = 0.99 * original + 0.01 * square_pixelated(original)'
    return group

bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=1;s.cycles.use_denoising=False;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8';s.render.resolution_percentage=100
s.view_settings.view_transform='Standard';s.view_settings.look='None';s.view_settings.exposure=0;s.view_settings.gamma=1
d=bpy.data.cameras.new('Compositor preview camera');cam=bpy.data.objects.new(d.name,d);s.collection.objects.link(cam);s.camera=cam
s.use_nodes=True;n=s.node_tree.nodes;n.clear();l=s.node_tree.links
src=n.new('CompositorNodeImage');src.location=(-400,100);filter=n.new('CompositorNodeGroup');filter.node_tree=make_pixel_group();filter.location=(-100,100);filter.inputs['Strength'].default_value=.01;filter.inputs['Block pixels'].default_value=14
dest=n.new('CompositorNodeComposite');dest.location=(220,100);l.new(src.outputs['Image'],filter.inputs['Image']);l.new(filter.outputs['Image'],dest.inputs[0])
records=[]
for filename,outname in [('02_asset_daylight.png','01_daylight_1pct.png'),('01_comparison.png','02_evening_1pct.png')]:
    im=bpy.data.images.load(str(source/filename));im.pack();src.image=im;w,h=im.size;s.render.resolution_x=w;s.render.resolution_y=h;s.render.filepath=str(root/outname)
    bpy.ops.render.render(write_still=True);records.append({'source':filename,'output':outname,'size':[w,h],'strength':.01,'block_pixels':14});print('PIXEL_TEST_READY',outname,flush=True)
src.image=bpy.data.images.get('02_asset_daylight.png');s.render.resolution_x=1440;s.render.resolution_y=1100;s.render.filepath=str(root/'01_daylight_1pct.png')
s['effect_note']='Exact 1% compositor mix. Set Strength to 0.01 for 1%, 0.05 for 5%. Block size is 14 source pixels. V5 geometry and materials are unchanged.'
bpy.ops.wm.save_as_mainfile(filepath=str(root/'pixelation_preview.blend'))
(root/'settings.json').write_text(json.dumps(records,indent=2));print('PIXEL_PROJECT_READY',flush=True)
