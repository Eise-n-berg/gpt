"""Run in Blender with a V5 model open; writes a separate scene copy."""
import bpy
from pathlib import Path
folder=Path(__file__).resolve().parent;name='Pixelation • adjustable 1 percent'
with bpy.data.libraries.load(str(folder/'pixelation_preview.blend'),link=False) as (available,loaded):
    loaded.node_groups=[name]
group=loaded.node_groups[0];scene=bpy.context.scene;scene.use_nodes=True;tree=scene.node_tree
composite=next(n for n in tree.nodes if n.type=='COMPOSITE')
assert composite.inputs[0].is_linked,'Connect a render image to Composite first'
source=composite.inputs[0].links[0].from_socket
node=tree.nodes.new('CompositorNodeGroup');node.node_tree=group;node.label='Pixelation: Strength 0.01 = 1%';node.inputs['Strength'].default_value=.01;node.inputs['Block pixels'].default_value=14
tree.links.new(source,node.inputs['Image']);tree.links.new(node.outputs['Image'],composite.inputs[0])
path=Path(bpy.data.filepath);assert path.name,'Save the scene once before applying the effect'
target=path.with_name(path.stem+'_pixel_1pct.blend');bpy.ops.wm.save_as_mainfile(filepath=str(target));print('PIXELATION_SCENE_SAVED',target)
