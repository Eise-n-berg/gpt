import bpy, os
s=bpy.context.scene;root=os.path.dirname(bpy.data.filepath)
s.cycles.samples=32;s.cycles.use_denoising=False
s.render.resolution_x=1440;s.render.resolution_y=1152;s.render.resolution_percentage=100
for name,cam in [('01_overview','01 • Courtyard / hero'),('02_facade','V2 • Facade and age detail')]:
    s.camera=bpy.data.objects[cam];s.render.filepath=os.path.join(root,name+'_raw.png')
    bpy.ops.render.render(write_still=True)
    print('V2_RENDER_READY',name,flush=True)
print('V2_RENDERS_COMPLETE',flush=True)
