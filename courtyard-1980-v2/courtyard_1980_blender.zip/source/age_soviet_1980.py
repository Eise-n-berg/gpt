"""V2 look-development pass on the existing courtyard; Blender 4.3+.
Keeps V1 unchanged. No downloaded textures, external assets or add-ons.
Run: blender -b riverside_courtyard.blend -t 3 --python age_soviet_1980.py
"""
import bpy, bmesh, random, math, os, json, sys
from mathutils import Vector
from math import sin,cos,pi
random.seed(1980)
OUT=os.path.join(os.path.dirname(bpy.data.filepath),'v2'); os.makedirs(OUT,exist_ok=True)
scene=bpy.context.scene

def nodeset(name):
    m=bpy.data.materials.new(name); m.use_nodes=True
    n=m.node_tree.nodes; n.clear(); l=m.node_tree.links
    p=n.new('ShaderNodeBsdfPrincipled'); p.inputs['Roughness'].default_value=.8
    o=n.new('ShaderNodeOutputMaterial'); l.new(p.outputs[0],o.inputs['Surface'])
    return m,n,l,p
def node(n,kind,label):
    x=n.new(kind); x.label=label; return x
def mathnode(n,l,operation,a,b):
    m=node(n,'ShaderNodeMath',operation); m.operation=operation
    for i,v in enumerate([a,b]):
        if isinstance(v,(int,float)): m.inputs[i].default_value=v
        else:l.new(v,m.inputs[i])
    return m.outputs[0]
def vector(n,l,source,scale):
    v=node(n,'ShaderNodeVectorMath','Physical scale / metres'); v.operation='MULTIPLY'; v.inputs[1].default_value=scale; l.new(source,v.inputs[0]); return v.outputs[0]
def noise(n,l,vec,scale=1,detail=3,label='Noise'):
    v=node(n,'ShaderNodeTexNoise',label); v.inputs['Scale'].default_value=scale; v.inputs['Detail'].default_value=detail; v.inputs['Roughness'].default_value=.72; l.new(vec,v.inputs['Vector']); return v.outputs['Fac']
def ramp(n,l,source,stops,label='Colour variation'):
    r=node(n,'ShaderNodeValToRGB',label)
    for e in list(r.color_ramp.elements)[2:]:r.color_ramp.elements.remove(e)
    for i,(pos,col) in enumerate(stops):
        e=r.color_ramp.elements[i] if i<2 else r.color_ramp.elements.new(pos)
        e.position=pos; e.color=(*col,1)
    l.new(source,r.inputs[0]); return r.outputs[0]
def mix(n,l,a,b,fac=1,mode='MIX',label='Layer'):
    m=node(n,'ShaderNodeMixRGB',label); m.blend_type=mode
    for inp,value in zip(m.inputs,[fac,a,b]):
        if isinstance(value,(float,int)): inp.default_value=value
        elif isinstance(value,tuple): inp.default_value=(*value,1)
        else:l.new(value,inp)
    return m.outputs[0]
def bump(n,l,height,distance,strength,normal=None):
    b=node(n,'ShaderNodeBump','Surface relief'); b.inputs['Distance'].default_value=distance; b.inputs['Strength'].default_value=strength
    l.new(height,b.inputs['Height'])
    if normal:l.new(normal,b.inputs['Normal'])
    return b.outputs[0]
def finish(m):
    for i,n in enumerate(m.node_tree.nodes):n.location=((i%6)*220,-(i//6)*220)
    return m

def aged_wood(axis,paint=None,damp=False):
    label=('teal paint' if paint=='teal' else 'old ivory paint' if paint else 'dark timber' if damp else 'silvered timber')
    m,n,l,p=nodeset('V2 • '+label+' / '+axis)
    tc=node(n,'ShaderNodeTexCoord','Local grain coordinates'); local=tc.outputs['Object']
    scales={'X':(.75,65,65),'Y':(65,.75,65),'Z':(65,65,.75)}
    g=noise(n,l,vector(n,l,local,scales[axis]),1,3,'Long fibres, knots and weathering')
    base=ramp(n,l,g,[(.22,(.023,.025,.020)),(.44,(.092,.087,.064)),(.64,(.20,.205,.173)),(.80,(.30,.29,.238))],'Bleached grey and exposed old wood')
    info=node(n,'ShaderNodeObjectInfo','Each board has aged differently')
    varied=ramp(n,l,info.outputs['Random'],[(0,(.58,.58,.58)),(1,(1.07,1.07,1.07))],'Board-to-board variation')
    base=mix(n,l,base,varied,mode='MULTIPLY')
    geom=node(n,'ShaderNodeNewGeometry','Continuous weathering across separate logs')
    macro=noise(n,l,vector(n,l,geom.outputs['Position'],(2.2,2.2,.45)),1.35,2,'Rain tracks shared across wall courses')
    stain=ramp(n,l,macro,[(.25,(.33,.34,.28)),(.75,(1,1,.91))])
    base=mix(n,l,base,stain,mode='MULTIPLY')
    if paint:
        peel_scales={'X':(.65,48,48),'Y':(48,.65,48),'Z':(48,48,.65)}
        flake=noise(n,l,vector(n,l,local,peel_scales[axis]),1,2,'Paint splits along timber fibres')
        stops=[(.30,(0,0,0)),(.445,(1,1,1))] if paint=='teal' else [(.23,(0,0,0)),(.37,(1,1,1))]
        mask=ramp(n,l,flake,stops,'Mostly intact faded coating with local losses')
        pigment=(.045,.14,.105) if paint=='teal' else (.27,.30,.245)
        faded=mix(n,l,pigment,(.55,.53,.40),.06 if paint=='teal' else .12)
        base=mix(n,l,base,faded,mask,label='Old paint over exposed timber')
    xyz=node(n,'ShaderNodeSeparateXYZ','Height above ground'); l.new(geom.outputs['Position'],xyz.inputs[0])
    height=node(n,'ShaderNodeMapRange','Darker wet lower courses'); height.clamp=True
    for key,val in [('From Min',.15),('From Max',1.18),('To Min',.30 if damp else .47),('To Max',.80 if damp else 1.0)]:height.inputs[key].default_value=val
    l.new(xyz.outputs['Z'],height.inputs['Value'])
    base=mix(n,l,base,height.outputs['Result'],mode='MULTIPLY',label='Rain and splash at base')
    l.new(base,p.inputs['Base Color'])
    rough=ramp(n,l,g,[(.2,(.68,.68,.68)),(.8,(.96,.96,.96))]); l.new(rough,p.inputs['Roughness'])
    micro_scales={'X':(1.8,260,260),'Y':(260,1.8,260),'Z':(260,260,1.8)}
    micro=noise(n,l,vector(n,l,local,micro_scales[axis]),1,2,'Fine split fibres')
    normal=bump(n,l,g,.017,.55)
    l.new(bump(n,l,micro,.005,.42,normal),p.inputs['Normal'])
    return finish(m)

wood={a:aged_wood(a) for a in 'XYZ'}
dark={a:aged_wood(a,damp=True) for a in 'XYZ'}
ivory={a:aged_wood(a,paint='ivory') for a in 'XYZ'}
teal={a:aged_wood(a,paint='teal') for a in 'XYZ'}
def local_axis(o):
    if o.type!='MESH':return 'Z'
    spans=[max(v[i] for v in o.bound_box)-min(v[i] for v in o.bound_box) for i in range(3)]
    return 'XYZ'[max(range(3),key=lambda i:spans[i])]

def aged_metal(name,zinc=False):
    m,n,l,p=nodeset(name)
    geom=node(n,'ShaderNodeNewGeometry','Continuous weathering across separate sheets'); v=geom.outputs['Position']
    tc=node(n,'ShaderNodeTexCoord','Sheet edges in local coordinates')
    patches=noise(n,l,vector(n,l,v,(1.35,.55,.85)),1.3,3,'Rare corrosion islands and rain tracks')
    mask=ramp(n,l,patches,[(.61,(0,0,0)),(.76,(1,1,1))],'Sparse oxide coverage')
    if zinc:
        xyz=node(n,'ShaderNodeSeparateXYZ','Standing seam edges');l.new(tc.outputs['Object'],xyz.inputs[0])
        edge=mathnode(n,l,'ABSOLUTE',xyz.outputs['X'],0)
        er=node(n,'ShaderNodeMapRange','Old corrosion close to folds');er.clamp=True
        for key,val in [('From Min',.155),('From Max',.179),('To Min',0),('To Max',.62)]:er.inputs[key].default_value=val
        l.new(edge,er.inputs['Value'])
        edge_mask=mathnode(n,l,'MULTIPLY',er.outputs['Result'],noise(n,l,v,9,2,'Broken seam staining'))
        mask=mathnode(n,l,'MAXIMUM',mask,edge_mask)
    clouds=noise(n,l,v,1.1,3,'Dull uneven zinc oxidation')
    silver=ramp(n,l,clouds,[(.2,(.023,.029,.030)),(.8,(.095,.105,.099))],'Dark weathered zinc')
    info=node(n,'ShaderNodeObjectInfo','Replacement sheets of different ages')
    silver=mix(n,l,silver,ramp(n,l,info.outputs['Random'],[(0,(.72,.72,.72)),(1,(1.08,1.08,1.08))]),mode='MULTIPLY')
    rusty=ramp(n,l,noise(n,l,v,35,2,'Powdery oxide'),[(.25,(.023,.014,.008)),(.7,(.14,.055,.014))],'Deep brown oxide')
    l.new(mix(n,l,silver,rusty,mask),p.inputs['Base Color'])
    l.new(mix(n,l,(.70,.70,.70),(.96,.96,.96),mask),p.inputs['Roughness'])
    l.new(mix(n,l,(.56,.56,.56),(.045,.045,.045),mask),p.inputs['Metallic'])
    fine=noise(n,l,v,160,2,'Pitting')
    normal=bump(n,l,patches,.008,.45); l.new(bump(n,l,fine,.0025,.5,normal),p.inputs['Normal'])
    return finish(m)
zinc=aged_metal('V2 • oxidised roof zinc / rust and pitting',True)
iron=aged_metal('V2 • old hardware / oxide')

def ground_material(name,road=False,garden=False):
    m,n,l,p=nodeset(name); geom=node(n,'ShaderNodeNewGeometry','World scale earth'); v=geom.outputs['Position']
    broad=noise(n,l,v,.7,3,'Uneven old moss and clay')
    colors=[(.2,(.025,.027,.014)),(.5,(.070,.060,.034)),(.8,(.145,.119,.072))]
    if road:colors=[(.2,(.027,.023,.016)),(.5,(.095,.073,.043)),(.8,(.19,.153,.096))]
    if garden:colors=[(.2,(.012,.011,.007)),(.7,(.055,.039,.019))]
    base=ramp(n,l,broad,colors,'Patchy clay, humus and moss')
    middle=noise(n,l,v,8,3,'Small clods')
    particles=ramp(n,l,middle,[(.2,(.48,.45,.36)),(.8,(1.1,1.05,.9))])
    l.new(mix(n,l,base,particles,mode='MULTIPLY'),p.inputs['Base Color'])
    wet=ramp(n,l,broad,[(.2,(.21,.21,.21)),(.65,(.94,.94,.94))],'Wet depressions and dry earth'); l.new(wet,p.inputs['Roughness'])
    fine=noise(n,l,v,95,2,'Grit')
    normal=bump(n,l,middle,.045,.65); l.new(bump(n,l,fine,.006,.4,normal),p.inputs['Normal'])
    return finish(m)
earth=ground_material('V2 • patchy earth and moss')
road=ground_material('V2 • damp clay road',True)
soil=ground_material('V2 • garden humus',garden=True)

m,n,l,p=nodeset('V2 • old log ends / faded rings')
tc=node(n,'ShaderNodeTexCoord','End grain'); sub=node(n,'ShaderNodeVectorMath','Centre of growth rings'); sub.operation='SUBTRACT'; sub.inputs[1].default_value=(.5,.5,.5); l.new(tc.outputs['Generated'],sub.inputs[0])
wa=node(n,'ShaderNodeTexWave','Growth rings'); wa.wave_type='RINGS'; wa.rings_direction='Z'; wa.inputs['Scale'].default_value=6; wa.inputs['Distortion'].default_value=3; l.new(sub.outputs[0],wa.inputs['Vector'])
l.new(ramp(n,l,wa.outputs['Fac'],[(.15,(.035,.040,.032)),(.85,(.125,.132,.11))]),p.inputs['Base Color'])
l.new(bump(n,l,wa.outputs['Fac'],.002,.3),p.inputs['Normal']); endgrain=finish(m)

for o in list(scene.objects):
    if o.type not in ['MESH','CURVE']:continue
    axis=local_axis(o)
    for slot in o.material_slots:
        if not slot.material:continue
        name=slot.material.name
        if name.startswith('WOOD • cut log ends'):slot.material=endgrain
        elif name.startswith('WOOD • damp'):slot.material=dark[axis]
        elif name.startswith('WOOD •'):slot.material=wood[axis]
        elif name.startswith('PAINT •'):slot.material=ivory[axis]
        elif name.startswith('ROOF •'):slot.material=zinc
        elif name.startswith('IRON •'):slot.material=iron
        elif name.startswith('EARTH •'):slot.material=earth
        elif name.startswith('ROAD •'):slot.material=road
        elif name.startswith('SOIL •'):slot.material=soil
    if o.name.startswith('Door boards'):o.data.materials.clear(); o.data.materials.append(teal[axis])
    if o.name.startswith(('Horizontal pine log','Interlocking side log')):
        for poly in o.data.polygons:
            if len(poly.vertices)==4:poly.use_smooth=True
    if o.name.startswith('Uneven split picket'):
        zmin=min(v.co.z for v in o.data.vertices); zmax=max(v.co.z for v in o.data.vertices)
        dx,dy=random.uniform(-.045,.045),random.uniform(-.03,.03)
        for v in o.data.vertices:
            h=(v.co.z-zmin)/(zmax-zmin); v.co.x+=dx*h; v.co.y+=dy*h

print('V2: layered wood, paint, metal and ground ready',flush=True)

# Foliage gets surface variation and a small amount of transmitted light.
for material in list(bpy.data.materials):
    if not material.name.startswith(('LEAF •','GRASS •')):continue
    old=material.node_tree.nodes.get('Principled BSDF'); color=tuple(old.inputs['Base Color'].default_value[:3])
    n=material.node_tree.nodes; l=material.node_tree.links
    geom=node(n,'ShaderNodeNewGeometry','Spatial leaf variation')
    no=noise(n,l,geom.outputs['Position'],4.5,2,'Uneven autumn colour')
    c1=tuple(v*.48 for v in color); c2=tuple(v*1.25 for v in color)
    l.new(ramp(n,l,no,[(.2,c1),(.8,c2)]),old.inputs['Base Color'])
    if material.name.startswith('LEAF •'):
        out=n.get('Material Output'); trans=node(n,'ShaderNodeBsdfTranslucent','Thin leaves')
        trans.inputs[0].default_value=(*color,1)
        mixshader=node(n,'ShaderNodeMixShader','Soft transmission'); mixshader.inputs[0].default_value=.15
        l.new(old.outputs[0],mixshader.inputs[1]); l.new(trans.outputs[0],mixshader.inputs[2]); l.new(mixshader.outputs[0],out.inputs['Surface'])
for o in list(scene.objects):
    if not o.name.startswith('Autumn leaves /'):continue
    vs=[]; fs=[]
    for poly in o.data.polygons:
        if len(poly.vertices)!=4:continue
        pts=[o.data.vertices[i].co.copy() for i in poly.vertices]; center=sum(pts,Vector())/4
        pts=[center+(p-center)*.86 for p in pts]
        k=len(vs); normal=(pts[1]-pts[0]).cross(pts[2]-pts[0]).normalized()
        vs.extend([tuple(p) for p in pts]); vs.append(tuple(center+normal*.009))
        fs.extend([(k+i,k+(i+1)%4,k+4) for i in range(4)])
    m=bpy.data.meshes.new(o.name+' / folded leaf surfaces'); m.from_pydata(vs,[],fs)
    for ma in o.data.materials:m.materials.append(ma)
    o.data=m

# The clay road has depressed wheel tracks; the old raised tube marks are removed.
for o in list(scene.objects):
    if o.name.startswith('Wheel rut'):bpy.data.objects.remove(o,do_unlink=True)
o=bpy.data.objects['Uneven riverbank']; vs=[tuple(v.co) for v in o.data.vertices]; fs=[]
for p in o.data.polygons:
    center=sum((o.data.vertices[i].co for i in p.vertices),Vector())/len(p.vertices)
    cy=-6.4+.33*sin(center.x*.30)
    if abs(center.y-cy)<.84:continue
    fs.append(tuple(p.vertices))
m=bpy.data.meshes.new('Bank / clear underneath road'); m.from_pydata(vs,[],fs); m.materials.append(earth); o.data=m
def ground(x,y):return .10+.045*sin(x*1.1)*cos(y*.8)+.026*sin(x*3+y*2)
vs=[]; fs=[]; indices=[]
for i in range(111):
    x=-11+i*.2; cy=-6.4+.33*sin(x*.30)
    for j in range(25):
        dy=-1+j/12; rut=.034*sum(math.exp(-((dy-v)/.085)**2) for v in [-.57,.57])
        vs.append((x,cy+dy,ground(x,cy+dy)+.046-rut))
    if i:
        for j in range(24):
            a=25*i+j; fs.append((a-25,a,a+1,a-24)); dy=-1+(j+.5)/12
            indices.append(int(min(abs(dy+.57),abs(dy-.57))<.075))
m=bpy.data.meshes.new('Road / soft sunken wheel tracks'); m.from_pydata(vs,[],fs); m.materials.append(road); m.materials.append(soil)
for poly,index in zip(m.polygons,indices):poly.material_index=index
bpy.data.objects['Dirt lane'].data=m
for o in list(scene.objects):
    if o.name.startswith('Rainwater in rut'):
        o.rotation_euler.z=.10*sin(o.location.x); o.location.z=ground(o.location.x,o.location.y)+.049
        o.data=o.data.copy()
        for v in o.data.vertices:v.co.x*=random.uniform(.88,1.12);v.co.y*=random.uniform(.85,1.15)

# Additional editable geometry, built directly without operator overhead.
col=bpy.data.collections.new('14 • V2 / weathering and 1980 rural details'); scene.collection.children.link(col)
def mesh(name,vs,fs,mat):
    m=bpy.data.meshes.new(name); m.from_pydata(vs,[],fs); m.update();m.materials.append(mat)
    o=bpy.data.objects.new(name,m); col.objects.link(o);return o
def cube(name,p,s,mat,bevel=0):
    points=[(x*s[0]/2,y*s[1]/2,z*s[2]/2) for x,y,z in [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]]
    o=mesh(name,points,[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)],mat);o.location=p
    if bevel:
        b=o.modifiers.new('Worn edge','BEVEL');b.width=bevel;b.segments=2
    return o
def beam(name,a,b,r,mat,vertices=8,r2=None):
    d=Vector(b)-Vector(a);rr=r if r2 is None else r2
    vs=[(rad*cos(i*2*pi/vertices),rad*sin(i*2*pi/vertices),z) for rad,z in [(r,-d.length/2),(rr,d.length/2)] for i in range(vertices)]
    fs=[tuple(reversed(range(vertices))),tuple(range(vertices,2*vertices))]+[(i,(i+1)%vertices,(i+1)%vertices+vertices,i+vertices) for i in range(vertices)]
    o=mesh(name,vs,fs,mat);o.location=(Vector(a)+Vector(b))/2;o.rotation_euler=d.to_track_quat('Z','Y').to_euler();return o
def curve(name,pts,r,mat):
    c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=1
    sp=c.splines.new('POLY');sp.points.add(len(pts)-1)
    for p,v in zip(sp.points,pts):p.co=(*v,1)
    c.materials.append(mat);o=bpy.data.objects.new(name,c);col.objects.link(o);return o
def ico(name,p,s,mat):
    m=bpy.data.meshes.new(name);bm=bmesh.new();bmesh.ops.create_icosphere(bm,subdivisions=2,radius=1);bm.to_mesh(m);bm.free();m.materials.append(mat)
    o=bpy.data.objects.new(name,m);col.objects.link(o);o.location=p;o.scale=s;return o
def solid(name,c,rough=.8,metal=0):
    m,n,l,p=nodeset(name);p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;return m
checks=solid('V2 • dark checks in timber',(.015,.017,.012))
rubber=solid('V2 • old rubber',(.009,.012,.012),.88)
ceramic=solid('V2 • glazed porcelain',(.46,.45,.36),.24)
enamel=solid('V2 • blue house-number enamel',(.014,.055,.10),.36,.15)
letters=solid('V2 • worn white lettering',(.62,.64,.50),.7)

# Long, irregular surface checks rather than identical clean cylinders.
for k in range(14):
    z=.45+k*.202
    for j in range(4):
        x=random.uniform(-5.45,-1.65);length=random.uniform(.20,.9);dz=random.uniform(-.035,.035)
        yy=-.7-math.sqrt(.116**2-dz**2)-.001
        pts=[(x+length*i/5,yy,z+dz+random.uniform(-.003,.003)) for i in range(6)]
        curve('Weather check / front log',pts,random.uniform(.0009,.0022),checks)
for k in range(12):
    z=.54+k*.202
    for j in range(3):
        y=random.uniform(-.5,2.8);length=random.uniform(.15,.70);dz=random.uniform(-.03,.03)
        xx=.3+math.sqrt(.113**2-dz**2)+.001
        curve('Weather check / side log',[(xx,y+length*i/4,z+dz+random.uniform(-.002,.002)) for i in range(5)],.0015,checks)

# Backlit linen breaks up the formerly uniform glowing window panels.
linen,n,l,p=nodeset('V2 • backlit old window curtains');p.inputs['Base Color'].default_value=(.32,.27,.17,1)
p.inputs['Emission Color'].default_value=(.55,.25,.075,1);p.inputs['Emission Strength'].default_value=.65
tc=node(n,'ShaderNodeTexCoord','Linen weave');weave=noise(n,l,tc.outputs['Generated'],90,2,'Linen weave');l.new(bump(n,l,weave,.001,.3),p.inputs['Normal'])
for x,y,side in [(-4.50,-.887,False),(-2.73,-.887,False),(.487,1.0,True),(.487,2.75,True)]:
    for sign in [-1,1]:
        vs=[];fs=[]
        for j in range(13):
            for i in range(9):
                dx=sign*(.14+i*.034);z=2.29-j*.077+.012*sin(i*1.8)*(j/12)
                depth=.006*sin(i*2.4)
                vs.append((x-depth,y+dx,z) if side else (x+dx,y+depth,z))
        for j in range(12):
            for i in range(8):
                a=j*9+i;fs.append((a,a+1,a+10,a+9))
        mesh('Linen curtain / faded folds',vs,fs,linen)
glass=bpy.data.materials['WINDOW • amber lamplight'];pg=glass.node_tree.nodes.get('Principled BSDF');pg.inputs['Emission Strength'].default_value=1.65

# TV aerial: a modest rural detail appropriate to an electrified village circa 1980.
beam('TV aerial / mast',(-.15,2.72,4.12),(-.15,2.72,6.05),.017,zinc,8)
beam('TV aerial / boom',(-.15,1.82,5.88),(-.15,3.65,5.88),.012,iron,6)
for j in range(6):
    y=1.88+j*.32; w=.53-j*.035
    beam('TV aerial / element',(-.15-w,y,5.88),(-.15+w,y,5.88),.007,zinc,6)
curve('TV aerial / coax',[(-.15,2.72,5.88),(-.12,2.71,4.16),(.4,2.7,4.04),(.43,2.65,3.25),(.43,2.65,2.30)],.005,rubber)

# Blue enamel house-number plate, with no invented street or region.
cube('Enamel house number 12',(-1.86,-.847,2.29),(.39,.035,.21),enamel,.018)
font=bpy.data.curves.new('House number 12','FONT');font.body='12';font.align_x='CENTER';font.align_y='CENTER';font.size=.155;font.extrude=.0008;font.materials.append(letters)
o=bpy.data.objects.new('House number / white 12',font);col.objects.link(o);o.location=(-1.86,-.869,2.29);o.rotation_euler=(pi/2,0,0)
for x in [-2.02,-1.70]:ico('Old sign screw',(x,-.869,2.29),(.009,.004,.009),iron)

# A simple old steel bicycle leaning near the fence, not a brand reconstruction.
bike=solid('V2 • old green steel bicycle paint',(.032,.070,.052),.72,.42);y=-3.67
rear=Vector((-5.30,y,.51));front=Vector((-4.00,y,.51));bb=Vector((-4.74,y,.50));seat=Vector((-4.96,y,1.04));head=Vector((-4.31,y,1.12));lower=Vector((-4.24,y,.91))
for center in [rear,front]:
    curve('Bicycle / tyre',[(center.x+.40*cos(i*pi/32),y,center.z+.40*sin(i*pi/32)) for i in range(65)],.027,rubber)
    curve('Bicycle / steel rim',[(center.x+.363*cos(i*pi/32),y,center.z+.363*sin(i*pi/32)) for i in range(65)],.009,zinc)
    for i in range(24):
        a=i*pi/12;beam('Bicycle / spoke',center,(center.x+.36*cos(a),y,center.z+.36*sin(a)),.0019,zinc,4)
    beam('Bicycle / axle',center-Vector((0,.045,0)),center+Vector((0,.045,0)),.023,iron,8)
    curve('Bicycle / old mudguard',[(center.x+.424*cos(a),y,center.z+.424*sin(a)) for a in [pi*.05+i*pi*.9/24 for i in range(25)]],.016,zinc)
for a,b in [(rear,seat),(seat,bb),(bb,rear),(bb,lower),(lower,head),(head,seat),(lower,front)]:beam('Bicycle / painted steel frame',a,b,.017,bike,8)
beam('Bicycle / seatpost',seat,seat+Vector((-.04,0,.18)),.012,zinc,7)
ico('Bicycle / old saddle',seat+Vector((-.04,0,.20)),(.17,.09,.04),rubber)
beam('Bicycle / stem',head,head+Vector((-.03,0,.20)),.013,zinc,7)
beam('Bicycle / handlebar',head+Vector((-.03,-.23,.20)),head+Vector((-.03,.23,.20)),.013,zinc,7)
for sign in [-1,1]:beam('Bicycle / grip',head+Vector((-.03,sign*.15,.20)),head+Vector((-.03,sign*.25,.20)),.020,rubber,8)
curve('Bicycle / chain',[(rear.x,y-.035,rear.z),(bb.x,y-.035,bb.z+.09),(bb.x,y-.035,bb.z-.09),(rear.x,y-.035,rear.z)],.006,iron)
beam('Bicycle / crank',bb+Vector((0,-.06,0)),bb+Vector((.10,-.06,-.11)),.012,iron,7)
cube('Bicycle / pedal',bb+Vector((.10,-.12,-.11)),(.13,.14,.028),rubber,.009)

# Zinc pail and bent wire handle, beside the well.
bx,by=1.44,-.55;bz=ground(bx,by)
vs=[(bx+r*cos(i*pi/12),by+r*sin(i*pi/12),bz+z) for r,z in [(.145,0),(.19,.29)] for i in range(24)]
fs=[(i,(i+1)%24,(i+1)%24+24,i+24) for i in range(24)]+[tuple(reversed(range(24)))]
mesh('Old zinc bucket',vs,fs,zinc)
curve('Bucket / rolled rim',[(bx+.192*cos(i*pi/16),by+.192*sin(i*pi/16),bz+.29) for i in range(33)],.009,iron)
curve('Bucket / wire handle',[(bx+.19*cos(a),by,bz+.26+.25*sin(a)) for a in [i*pi/20 for i in range(21)]],.007,iron)

# Replace decorative street lanterns with simple electric reflectors and porcelain insulators.
lamp_enamel=solid('V2 • dull reflector enamel',(.25,.28,.245),.58,.18)
for o in list(scene.objects):
    if o.name.startswith(('Lantern lower cap','Lantern glow','Lantern frame','Lantern rain cap')) and o.location.z>2.90:
        bpy.data.objects.remove(o,do_unlink=True)
for x,y in [(-2.1,-5.5),(7.9,-5.8)]:
    beam('Electric pole / crossarm',(x,y-.35,3.42),(x,y+.35,3.42),.04,wood['Z'],4)
    for dy in [-.23,.23]:
        beam('Porcelain insulator / pin',(x,y+dy,3.42),(x,y+dy,3.61),.009,iron,6)
        for z,r in [(3.49,.037),(3.54,.046),(3.59,.035)]:ico('Porcelain insulator',(x,y+dy,z),(r,r,.023),ceramic)
    lx=x+.52
    vs=[(lx+r*cos(i*pi/12),y+r*sin(i*pi/12),z) for r,z in [(.23,3.23),(.045,3.36)] for i in range(24)]
    fs=[(i,(i+1)%24,(i+1)%24+24,i+24) for i in range(24)]
    mesh('Street light / worn enamel reflector',vs,fs,lamp_enamel)
    bulb=bpy.data.materials['LANTERN • flame'];ico('Street light / incandescent bulb',(lx,y,3.16),(.065,.065,.083),bulb)
for o in list(scene.objects):
    if o.name.startswith('Sagging overhead wire'):bpy.data.objects.remove(o,do_unlink=True)
for offset in [-.23,.23]:
    curve('Electric supply / sagging two-wire line',[(-2.1+i*.25,-5.5-i*.0075+offset,3.61-.36*sin(i*pi/40)) for i in range(41)],.007,iron)

print('V2: period details, checks, curtains and road geometry ready',flush=True)
scene.camera=bpy.data.objects['01 • Courtyard / hero']
scene.cycles.use_denoising=False;scene.cycles.samples=32
scene.render.resolution_x=1280;scene.render.resolution_y=1024;scene.render.resolution_percentage=100
scene.render.filepath=os.path.join(OUT,'01_overview_raw.png')
scene['version']='V2 / rural USSR circa 1980 / weathering look development'
scene['historical_note']='Generic rural interpretation, not a reconstruction of a specific village or region.'
# A closer facade camera makes surface changes reviewable.
data=bpy.data.cameras.new('V2 • Facade and age detail');cam=bpy.data.objects.new(data.name,data);scene.collection.objects.link(cam)
cam.location=(9,-17,9);cam.rotation_euler=(Vector((-2.35,-.45,1.65))-cam.location).to_track_quat('-Z','Y').to_euler();data.type='ORTHO';data.ortho_scale=10.4
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'riverside_courtyard_1980_v2.blend'))
with open(os.path.join(OUT,'scene_info.json'),'w') as f:json.dump({'version':'V2','objects':len(scene.objects),'polygons':sum(len(o.data.polygons) for o in scene.objects if o.type=='MESH'),'external_textures':0,'setting':'rural USSR circa 1980'},f,indent=2)
if '--skip-preview' not in sys.argv:
    scene.render.resolution_x=900;scene.render.resolution_y=720;scene.cycles.samples=16
    scene.render.filepath=os.path.join(OUT,'preview_raw.png');bpy.ops.render.render(write_still=True)
    print('V2_PREVIEW_COMPLETE',flush=True)
else:print('V2_SCENE_READY',flush=True)
