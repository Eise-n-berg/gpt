"""Rebuild the reference-inspired riverside courtyard in Blender 4.3+.
Usage: blender -b --python build_courtyard.py -- --out /path --preview
All geometry and materials are generated locally; no downloads or add-ons.
"""
import bpy, bmesh, math, random, os, sys, argparse, json
from mathutils import Vector
from mathutils.noise import noise_vector
from math import sin, cos, pi

parser=argparse.ArgumentParser()
parser.add_argument('--out',default=os.path.dirname(os.path.abspath(__file__)))
parser.add_argument('--preview',action='store_true')
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
OUT=os.path.abspath(args.out); os.makedirs(OUT,exist_ok=True)
random.seed(271)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for block in list(bpy.data.collections):
    if block.name!='Collection': bpy.data.collections.remove(block)
root=bpy.context.scene.collection
current=None
def collection(name):
    global current
    current=bpy.data.collections.new(name); root.children.link(current)
    print('BUILD',name,flush=True)
    return current
def put(o,name,mat=None):
    o.name=name
    for c in list(o.users_collection): c.objects.unlink(o)
    current.objects.link(o)
    if mat: o.data.materials.append(mat)
    return o
def mesh(name,vs,fs,mat):
    m=bpy.data.meshes.new(name); m.from_pydata(vs,[],fs); m.update()
    o=bpy.data.objects.new(name,m); current.objects.link(o)
    if mat: m.materials.append(mat)
    return o
def cube(name,p,s,mat,bevel=0,rot=None):
    vs=[(x*s[0]/2,y*s[1]/2,z*s[2]/2) for x,y,z in [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]]
    o=mesh(name,vs,[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)],mat); o.location=p
    if rot: o.rotation_euler=rot
    if bevel:
        m=o.modifiers.new('Worn edges','BEVEL'); m.width=bevel; m.segments=2
    return o
def beam(name,a,b,r,mat,vertices=8,r2=None):
    d=Vector(b)-Vector(a)
    rr=r if r2 is None else r2
    vs=[(radius*cos(i*2*pi/vertices),radius*sin(i*2*pi/vertices),z) for radius,z in [(r,-d.length/2),(rr,d.length/2)] for i in range(vertices)]
    fs=[tuple(reversed(range(vertices))),tuple(range(vertices,2*vertices))]
    fs += [(i,(i+1)%vertices,(i+1)%vertices+vertices,i+vertices) for i in range(vertices)]
    o=mesh(name,vs,fs,mat); o.location=(Vector(a)+Vector(b))/2; o.rotation_euler=d.to_track_quat('Z','Y').to_euler()
    return o
ico_meshes={}
def ico(name,p,s,mat,sub=1):
    key=(mat.name,sub)
    if key not in ico_meshes:
        m=bpy.data.meshes.new('Shared ico / '+mat.name); bm=bmesh.new(); bmesh.ops.create_icosphere(bm,subdivisions=sub,radius=1); bm.to_mesh(m); bm.free(); m.materials.append(mat); ico_meshes[key]=m
    o=bpy.data.objects.new(name,ico_meshes[key]); current.objects.link(o); o.location=p; o.scale=s
    o.rotation_euler=[random.random()*pi for _ in range(3)]
    if name in ['Rainwater in rut','Well dark opening','Worn stepping stone']:
        o.rotation_euler.x=0; o.rotation_euler.y=0
    return o
def curve(name,points,r,mat):
    c=bpy.data.curves.new(name,'CURVE'); c.dimensions='3D'; c.bevel_depth=r; c.bevel_resolution=1
    sp=c.splines.new('POLY'); sp.points.add(len(points)-1)
    for v,p in zip(sp.points,points): v.co=(*p,1)
    o=bpy.data.objects.new(name,c); current.objects.link(o); c.materials.append(mat); return o
def material(name,c,rough=.8,metal=0):
    m=bpy.data.materials.new(name); m.diffuse_color=(*c,1); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*c,1)
    p.inputs['Roughness'].default_value=rough; p.inputs['Metallic'].default_value=metal
    return m
def textured(name,c1,c2,scale=5,stretch=(1,1,1),bump=.1,rough=.8,metal=0):
    m=material(name,c1,rough,metal); n=m.node_tree.nodes; l=m.node_tree.links; p=n.get('Principled BSDF')
    t=n.new('ShaderNodeTexCoord'); v=n.new('ShaderNodeVectorMath'); v.operation='MULTIPLY'; v.inputs[1].default_value=stretch
    l.new(t.outputs['Generated'],v.inputs[0]); no=n.new('ShaderNodeTexNoise'); no.inputs['Scale'].default_value=scale
    no.inputs['Detail'].default_value=4; no.inputs['Roughness'].default_value=.72; l.new(v.outputs[0],no.inputs['Vector'])
    ramp=n.new('ShaderNodeValToRGB'); ramp.color_ramp.elements[0].position=.23; ramp.color_ramp.elements[1].position=.79
    ramp.color_ramp.elements[0].color=(*c1,1); ramp.color_ramp.elements[1].color=(*c2,1)
    l.new(no.outputs['Fac'],ramp.inputs[0]); l.new(ramp.outputs[0],p.inputs['Base Color'])
    bu=n.new('ShaderNodeBump'); bu.inputs['Strength'].default_value=bump; bu.inputs['Distance'].default_value=.055
    l.new(no.outputs['Fac'],bu.inputs['Height']); l.new(bu.outputs[0],p.inputs['Normal'])
    return m
wood=textured('WOOD • silvered pine / longitudinal grain',(.055,.048,.038),(.24,.205,.148),5,(5,5,.24),.38)
plank=textured('WOOD • sawn boards / weathered',(.055,.063,.062),(.23,.23,.19),4,(.6,13,9),.35)
trim=textured('PAINT • worn ivory',(.12,.14,.126),(.47,.46,.35),6,(1,8,5),.24)
darkwood=textured('WOOD • damp dark endgrain',(.025,.022,.016),(.14,.094,.049),6,(3,3,.25),.3)
roof=textured('ROOF • weathered zinc',(.028,.037,.042),(.115,.133,.135),6,(3,1,10),.22,.6,.55)
rust=textured('IRON • oxidised seams',(.045,.038,.03),(.19,.105,.051),9,(1,1,1),.3,.77,.35)
iron=material('IRON • charcoal',(.028,.034,.035),.65,.65)
stone=textured('STONE • river granite',(.065,.079,.077),(.26,.28,.25),4,(1,1,1),.38)
earth=textured('EARTH • clay and moss',(.043,.043,.025),(.22,.18,.112),35,(1,1,1),.55)
soil=textured('SOIL • turned garden beds',(.025,.02,.012),(.095,.073,.039),18,(1,1,1),.65)
roadmat=textured('ROAD • wet compacted soil',(.045,.038,.029),(.23,.19,.13),22,(1,1,1),.35,.65)
grassm=[material('GRASS • '+str(i),c) for i,c in enumerate([(.095,.105,.043),(.18,.16,.07),(.26,.22,.10),(.065,.09,.048)])]
leafm=[material('LEAF • '+str(i),c) for i,c in enumerate([(.1005,.0676,.02025),(.2077,.0988,.0216),(.2814,.13,.03105),(.05695,.0572,.0261),(.134,.1144,.045)])]
bark=textured('BARK • birch',(.18,.17,.14),(.59,.55,.41),7,(6,6,.7),.55)
black=material('BARK • scars',(.035,.034,.024))
cabbage=material('GARDEN • cabbage leaves',(.12,.20,.10))
cutwood=material('WOOD • cut log ends',(.34,.215,.105))
def emissive(name,c,strength):
    m=material(name,c,.3); p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Emission Color'].default_value=(*c,1); p.inputs['Emission Strength'].default_value=strength; return m
glass=emissive('WINDOW • amber lamplight',(1,.40,.075),3.0)
glass.node_tree.nodes.get('Principled BSDF').inputs['Emission Color'].default_value=(1,.31,.045,1)
glass.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=2.0
lampglass=emissive('LANTERN • flame',(1,.51,.16),5)
water=textured('WATER • river ripples',(.012,.025,.034),(.038,.069,.086),380,(.5,6,1),.18,.22,.45)
puddle=material('WATER • shallow puddles',(.052,.059,.054),.13,.35)

def ground(x,y):
    return .10+.045*sin(x*1.1)*cos(y*.8)+.026*sin(x*3+y*2)

collection('01 • SHORE / terrain & water')
# A natural, uneven river bank, rather than a display plinth.
N=92; vs=[]; fs=[]
for j in range(N+1):
    v=j/N
    for i in range(N+1):
        u=i/N; x=-10+20*u
        front=-8.4+.48*sin(x*.55)+.20*sin(x*1.8)
        y=front+(9.4-front)*v
        z=ground(x,y)
        edge=min(u,1-u,v,1-v)
        if edge<.045: z-=.7*(1-edge/.045)
        if v<.07: z-=.22*(1-v/.07)
        vs.append((x,y,z))
for j in range(N):
    for i in range(N):
        a=j*(N+1)+i; fs.append((a,a+1,a+N+2,a+N+1))
mesh('Uneven riverbank',vs,fs,earth)
cube('River',(0,-1,-.64),(200,200,.15),water)
for i in range(120):
    x=random.uniform(-10,10); y=-8.25+.48*sin(x*.55)+random.uniform(-.5,.15)
    s=random.uniform(.13,.46); ico('Shore / granite boulder',(x,y,-.2),(s,s*.7,s*.67),stone,1)

collection('02 • ROAD / ruts and puddles')
vs=[]; fs=[]
for i in range(111):
    x=-11+i*.2; cy=-6.4+.33*sin(x*.30)
    for j in range(17):
        dy=-1+j/8; vs.append((x,cy+dy,ground(x,cy+dy)+.045))
    if i:
        for j in range(16):
            a=17*i+j; fs.append((a-17,a,a+1,a-16))
mesh('Dirt lane',vs,fs,roadmat)
for k in [-.57,.57]:
    pts=[]
    for i in range(111):
        x=-11+i*.2; y=-6.4+.33*sin(x*.3)+k+.035*sin(x*2)
        pts.append((x,y,ground(x,y)+.049))
    curve('Wheel rut',pts,.037,soil)
for x,y,s in [(-2,-6.6,.9),(2.8,-6,.7),(6,-6.5,.45),(-7,-6.3,.5)]:
    ico('Rainwater in rut',(x,y,ground(x,y)+.063),(s,.14,.008),puddle,2)

collection('03 • HOUSE / log shell & foundation')
cx=-2.7; cy=1.55; xmin=-5.7; xmax=.3; ymin=-.7; ymax=3.8
for x in [-5.55,-4,-2.5,-1,.15]:
    for y in [-.58,3.68]:
        ico('Fieldstone footing',(x,y,.24),(.42,.34,.29),stone,2)
cube('Dark joints behind logs',(cx,cy,1.63),(5.93,4.43,2.78),darkwood)
for k in range(14):
    z=.45+k*.202
    for y in [ymin,ymax]:
        beam('Horizontal pine log',(xmin-.13,y,z),(xmax+.13,y,z),.116+random.uniform(-.008,.008),wood,12)
    for x in [xmin,xmax]:
        beam('Interlocking side log',(x,ymin-.14,z+.09),(x,ymax+.14,z+.09),.113,wood,12)
        for y in [ymin-.148,ymax+.148]:
            # Visible golden end grain, slightly recessed beneath weathering.
            beam('Log end',(x,y-.006,z+.09),(x,y+.006,z+.09),.089,cutwood,12)
for x in [xmin-.025,xmax+.025]:
    mesh('Timber gable',[(x,ymin,3.21),(x,ymax,3.21),(x,cy,4.73)],[(0,1,2)],darkwood)
    for j in range(25):
        y=ymin+.07+j*.18; top=4.73-abs(y-cy)*(1.52/2.25)
        if top>3.23: cube('Gable vertical board',(x,y,(3.22+top)/2),(.065,.172,top-3.22),plank,.008)
    for a,b in [((x,ymin-.13,3.15),(x,cy,4.86)),((x,cy,4.86),(x,ymax+.13,3.15))]: beam('Gable bargeboard',a,b,.085,trim,4)

collection('04 • HOUSE / zinc roof & chimney')
rise=1.70; run=2.63; ridge=4.85; angle=math.atan2(rise,run); slope=math.hypot(rise,run)
for side in [-1,1]:
    for j in range(19):
        x=xmin-.45+(j+.5)*6.9/19
        cube('Standing seam roof panel',(x,cy+side*run/2,ridge-rise/2),(.356,slope,.055),roof,.009,(-side*angle,0,0))
        beam('Raised zinc seam',(x-.18,cy,ridge+.035),(x-.18,cy+side*run,ridge-rise+.035),.012,roof,6)
    beam('Eave fascia',(xmin-.5,cy+side*run,ridge-rise-.02),(xmax+.5,cy+side*run,ridge-rise-.02),.065,plank,4)
beam('Roof ridge cap',(xmin-.53,cy,4.88),(xmax+.53,cy,4.88),.095,roof,6)
brick=textured('CHIMNEY • sooty brick',(.07,.052,.036),(.25,.14,.08),8,(1,1,1),.3)
cube('Brick chimney',(-3.9,2.2,4.68),(.48,.51,1.35),brick,.025)
for z in [4.2,4.4,4.6,4.8,5,5.2]:
    cube('Mortar joint',(-3.9,1.94,z),(.49,.008,.012),stone)
cube('Chimney crown',(-3.9,2.2,5.37),(.62,.65,.13),stone,.025)
cube('Chimney darkness',(-3.9,2.2,5.442),(.34,.34,.008),iron)

collection('05 • HOUSE / windows, carved trim & porch')
def point(name,p,power,color,r=.4):
    d=bpy.data.lights.new(name,'POINT'); d.energy=power; d.color=color; d.shadow_soft_size=r
    o=bpy.data.objects.new(name,d); current.objects.link(o); o.location=p; return o
def window_front(x,y,z,w=.83,h=1.05,side=False):
    # Window assembly built in its own local front plane, then rotated for the side wall.
    objs_before=set(current.objects)
    cube('Window / deep surround',(x,y,z),(w+.22,.12,h+.24),darkwood,.025)
    cube('Window / warm glass',(x,y-.073,z),(w,.035,h),glass,.012)
    for dx in [-w/2-.035,w/2+.035]: cube('Window / carved upright',(x+dx,y-.12,z),(.095,.13,h+.24),trim,.013)
    for dz in [-h/2-.055,h/2+.06]: cube('Window / sill and lintel',(x,y-.14,z+dz),(w+.34,.22,.105),trim,.016)
    cube('Window / mullion',(x,y-.112,z),(.04,.08,h),darkwood,.008)
    cube('Window / transom',(x,y-.112,z+.07),(w,.08,.038),darkwood,.007)
    # Small upper carved blocks; restrained village ornament.
    for dx in [-.30,-.15,0,.15,.30]: cube('Lintel notch',(x+dx,y-.15,z+h/2+.15),(.07,.09,.065),trim,.008)
    if side:
        for o in set(current.objects)-objs_before:
            d=o.location-Vector((x,y,z)); o.location=Vector((x,y,z))+Vector((-d.y,d.x,d.z)); o.rotation_euler.z+=pi/2
        point('Window spill',(x+.38,y,z),32,(1,.49,.16),.55)
    else: point('Window spill',(x,y-.38,z),38,(1,.48,.16),.55)
window_front(-4.50,ymin-.09,1.78)
window_front(-2.73,ymin-.09,1.78)
window_front(xmax+.09,1.00,1.78,side=True)
window_front(xmax+.09,2.75,1.78,side=True)
cube('Door recess',(-.92,ymin-.14,1.48),(1.0,.16,2.2),darkwood,.03)
for j in range(6): cube('Door boards',(-1.32+j*.16,ymin-.25,1.46),(.151,.07,2.05),plank,.008)
for x in [-1.46,-.38]: cube('Door casing',(x,ymin-.3,1.5),(.10,.15,2.29),trim,.012)
cube('Door lintel',(-.92,ymin-.3,2.64),(1.2,.16,.11),trim,.012)
ico('Door latch',(-.58,ymin-.32,1.43),(.04,.03,.04),iron,2)
for i in range(9): cube('Porch deck board',(-1.55+i*.18,-1.4,.44),(.172,1.45,.10),plank,.009)
for i in range(3): cube('Porch step',(-.85,-2.22-i*.27,.36-i*.105),(1.73,.30,.14),plank,.015)
for x in [-1.67,.08]:
    beam('Porch post',(x,-2.03,.38),(x,-2.03,2.7),.065,trim,8)
    beam('Porch knee brace',(x,-2.03,2.15),(x+(.35 if x<0 else -.35),-2.03,2.6),.043,trim,4)
cube('Porch canopy',(-.80,-1.42,2.78),(2.1,1.9,.10),roof,.02,(.12,0,0))
for x in [-1.81,.23]: beam('Canopy edge',(x,-.5,2.92),(x,-2.37,2.69),.055,plank,4)
point('Porch lantern light',(-.73,-1.53,2.42),65,(1,.44,.12),.28)

collection('06 • OUTBUILDINGS / shed & firewood')
def shed(cx,cy,w,d,h):
    cube('Shed inner shadow',(cx,cy,h/2+.15),(w-.06,d-.06,h),darkwood)
    for j in range(int(w/.21)):
        x=cx-w/2+(j+.5)*w/int(w/.21)
        for y in [cy-d/2,cy+d/2]: cube('Shed vertical cladding',(x,y,h/2+.15),(.195,.10,h+random.uniform(-.035,.035)),plank,.009)
    for j in range(int(d/.21)):
        y=cy-d/2+(j+.5)*d/int(d/.21)
        for x in [cx-w/2,cx+w/2]: cube('Shed side cladding',(x,y,h/2+.15),(.10,.195,h),plank,.009)
    for s in [-1,1]:
        r=d/2+.25; rise=.7; a=math.atan2(rise,r)
        cube('Shed corrugated roof',(cx,cy+s*r/2,h+.15+rise/2),(w+.5,math.hypot(r,rise),.065),roof,.012,(-s*a,0,0))
        for j in range(int(w/.22)+2):
            x=cx-w/2-.12+j*.22
            beam('Shed roofing seam',(x,cy,h+.87),(x,cy+s*r,h+.17),.013,roof,5)
    cube('Shed door',(cx-.35,cy-d/2-.065,1.04),(1.15,.10,1.8),darkwood,.02)
    for dx in [-.84,.15]: cube('Door jamb',(cx+dx,cy-d/2-.13,1.04),(.08,.12,1.91),plank,.008)
    beam('Door brace',(cx-.82,cy-d/2-.14,.28),(cx+.11,cy-d/2-.14,1.82),.05,plank,4)
    cube('Shed small pane',(cx+w*.31,cy-d/2-.09,1.58),(.38,.04,.43),glass,.01)
    cube('Shed pane cross',(cx+w*.31,cy-d/2-.125,1.58),(.035,.045,.46),plank)
shed(4.4,4.20,3.3,2.5,2.35)
# Lean-to behind the right side of the house.
for x in [1.1,2.4]: beam('Woodstore uprights',(x,2.55,.1),(x,2.55,1.9),.065,wood,8)
cube('Woodstore lean-to roof',(1.7,3.0,1.98),(1.9,1.7,.09),roof,.015,(.20,0,0))
for row in range(6):
    for col in range(5-row//2):
        x=1.14+col*.24+(row%2)*.1; z=.25+row*.21
        beam('Stacked firewood',(x,2.52,z),(x,3.45,z),.115,darkwood,9)
        beam('Fresh endgrain',(x,2.505,z),(x,2.52,z),.093,cutwood,9)

collection('07 • FENCE / irregular pickets & gate')
def fence(a,b,gate=False):
    a=Vector((*a,0)); b=Vector((*b,0)); d=b-a; length=d.length; t=d.normalized(); across=Vector((-t.y,t.x,0))
    count=max(1,round(length/.24))
    for i in range(count+1):
        p=a+d*i/count; z=ground(p.x,p.y); h=random.uniform(.76,1.04)
        w=.115; top=h-.10
        vs=[]
        for dep in [-.022,.022]:
            for off,zz in [(-w/2,0),(w/2,0),(w/2,top),(0,h),(-w/2,top)]:
                v=p+t*off+across*dep; vs.append((v.x,v.y,z+zz))
        mesh('Uneven split picket',vs,[(0,1,2,3,4),(5,9,8,7,6),(0,5,6,1),(1,6,7,2),(2,7,8,3),(3,8,9,4),(4,9,5,0)],plank)
    for h in [.28,.66]:
        aa=a+across*.045; bb=b+across*.045
        aa.z=ground(a.x,a.y)+h; bb.z=ground(b.x,b.y)+h
        beam('Fence rail',aa,bb,.043,wood,4)
    n=max(1,round(length/1.6))
    for i in range(n+1):
        p=a+d*i/n; beam('Fence post',(p.x,p.y,ground(p.x,p.y)),(p.x,p.y,ground(p.x,p.y)+1.12),.068,darkwood,6)
fence((-7,-4.85),(-1.55,-4.85)); fence((.75,-4.85),(7.25,-4.85))
fence((-7,-4.85),(-7,5.9)); fence((7.25,-4.85),(7.25,5.9)); fence((-7,5.9),(7.25,5.9))
# Gate left ajar, preserving the entrance to the yard.
fence((.75,-4.85),(1.0,-3.05))
beam('Gate diagonal',(.75,-4.85,.36),(1,-3.05,1.03),.04,wood,4)

collection('08 • GARDEN / beds & vegetables')
for j in range(4):
    x=2.8+j*.89
    cube('Raised vegetable bed',(x,-2.55,.14),(.66,3.16,.16),soil,.08)
    for dx in [-.37,.37]: beam('Bed edging',(x+dx,-4.18,.15),(x+dx,-.95,.15),.043,wood,6)
    for k in range(7):
        y=-3.94+k*.43
        if j in [0,1]:
            for n in range(6):
                a=n*pi/3+random.random()*.3
                ob=ico('Cabbage outer leaf',(x+.105*cos(a),y+.105*sin(a),.27),(.14,.10,.07),cabbage,1)
            ico('Cabbage heart',(x,y,.31),(.12,.12,.12),cabbage,2)
        else:
            for n in range(5):
                a=n*pi*2/5; beam('Late garden greens',(x,y,.22),(x+.14*cos(a),y+.14*sin(a),.47+random.random()*.16),.014,grassm[3],4,r2=.002)
    beam('Garden marker',(x,-4.23,.12),(x,-4.23,.62),.018,wood,5)
    cube('Marker label',(x,-4.23,.53),(.20,.035,.10),cutwood,.01)

collection('09 • YARD / well, barrels, bench & tools')
# Compact timber well in the open part of the courtyard.
wx,wy=2.10,.05
for i in range(16):
    a=i*pi/8
    cube('Well stave',(wx+.45*cos(a),wy+.45*sin(a),.46),(.17,.10,.65),plank,.012,(0,0,a+pi/2))
for z in [.24,.65]:
    curve('Well iron band',[(wx+.50*cos(i*pi/20),wy+.50*sin(i*pi/20),z) for i in range(41)],.025,iron)
ico('Well dark opening',(wx,wy,.70),(.39,.39,.016),iron,2)
for x in [wx-.67,wx+.67]: beam('Well upright',(x,wy,.1),(x,wy,1.98),.06,wood,6)
beam('Well spindle',(wx-.77,wy,1.35),(wx+.78,wy,1.35),.07,wood,10)
curve('Well rope',[(wx,wy,1.4),(wx+.02,wy,.6)],.012,cutwood)
for s in [-1,1]: cube('Well roof',(wx,wy+s*.37,2.02), (1.8,.85,.07),plank,.012,(-s*.40,0,0))
def barrel(x,y,sz=1):
    vs=[]; fs=[]; rings=[(0,.26),(.10,.30),(.48,.34),(.86,.29),(.94,.26)]
    for z,r in rings:
        for i in range(14): vs.append((x+sz*r*cos(i*2*pi/14),y+sz*r*sin(i*2*pi/14),ground(x,y)+z*sz))
    for k in range(4):
        for i in range(14): fs.append((k*14+i,k*14+(i+1)%14,(k+1)*14+(i+1)%14,(k+1)*14+i))
    fs.append(tuple(range(56,70))); mesh('Wooden rain barrel',vs,fs,wood)
    for z,r in [(.12,.306),(.73,.314)]: curve('Barrel hoop',[(x+r*sz*cos(i*pi/14),y+r*sz*sin(i*pi/14),ground(x,y)+z*sz) for i in range(29)],.024*sz,iron)
barrel(.88,2.0,.9); barrel(5.93,2.65,.8)
for x in [-4.9,-3.4]:
    for y in [-1.63,-1.95]: beam('Bench leg',(x,y,.1),(x,y,.58),.042,wood,6)
for j in range(3): cube('Bench seat',(-4.16,-1.66-j*.14,.61),(1.9,.13,.075),plank,.01)
beam('Bench backrest',(-5.1,-1.58,1.05),(-3.2,-1.58,1.05),.10,plank,4)
# Axe and chopping stump.
beam('Chopping block',(1.2,1.55,.12),(1.2,1.55,.55),.25,wood,12)
beam('Stump end',(1.2,1.55,.55),(1.2,1.55,.565),.23,cutwood,12)
beam('Axe haft',(1.23,1.55,.56),(1.42,1.58,1.13),.023,cutwood,6)
cube('Axe head',(1.40,1.58,1.07),(.26,.065,.13),iron,.015,(0,-.25,0))
for i in range(15):
    x=1.05+random.uniform(-.65,.6); y=1.25+random.uniform(-.6,.3)
    if (x-1.2)**2+(y-1.55)**2>.12: beam('Split firewood',(x,y,.16),(x+.20,y+.25,.18),.065,cutwood,5)
def crate(x,y,z):
    for h in range(4):
        zz=z+.06+h*.13
        for yy in [y-.27,y+.27]: cube('Crate slat',(x,yy,zz),(.68,.045,.105),plank,.007)
        for xx in [x-.32,x+.32]: cube('Crate end',(xx,y,zz),(.045,.54,.105),wood,.007)
    for xx in [x-.29,x+.29]:
        for yy in [y-.24,y+.24]: cube('Crate corner',(xx,yy,z+.23),(.05,.05,.53),darkwood,.006)
crate(3.19,2.83,.11); crate(3.91,2.78,.11)
# A wheel leaning against the shed, with individually modeled spokes.
ox,oy,oz=5.8,2.83,.60
curve('Cart wheel / rim',[(ox+.49*cos(i*pi/24),oy,oz+.49*sin(i*pi/24)) for i in range(49)],.045,darkwood)
for i in range(10):
    a=i*pi/5; beam('Cart wheel / spoke',(ox,oy,oz),(ox+.47*cos(a),oy,oz+.47*sin(a)),.018,wood,5)
beam('Cart wheel / hub',(ox,oy-.1,oz),(ox,oy+.1,oz),.08,wood,10)
# Clothesline and two faded pieces of linen.
linen=textured('FABRIC • undyed linen',(.20,.21,.18),(.47,.46,.37),18,(1,1,1),.15)
for x in [3.3,6.0]: beam('Clothesline post',(x,1.5,.1),(x,1.5,2.15),.037,wood,7)
curve('Sagging clothesline',[(3.3+i*.135,1.5,2.12-.17*sin(i*pi/20)) for i in range(21)],.009,cutwood)
for xx in [3.8,4.8]:
    vs=[]; fs=[]
    for j in range(9):
        for i in range(9):
            x=xx+i*.065; z=1.98-j*.09; y=1.5+.035*sin(i*1.8)+.045*(j/8)**2
            vs.append((x,y,z))
    for j in range(8):
        for i in range(8):
            a=j*9+i; fs.append((a,a+1,a+10,a+9))
    mesh('Linen drying in the yard',vs,fs,linen)

collection('10 • TREES / autumn birches')
# Real branch structure with airy clusters of individual leaves, avoiding solid blob crowns.
leaf_vs=[[] for _ in leafm]; leaf_fs=[[] for _ in leafm]
def leaves_at(center,radius,count):
    for i in range(count):
        v=Vector((random.gauss(0,1),random.gauss(0,1),random.gauss(0,.7)))
        if v.length>2: v.normalize(); v*=2
        p=Vector(center)+v*radius*.43
        a=random.random()*2*pi; s=random.uniform(.045,.10)
        u=Vector((cos(a)*s,sin(a)*s,random.uniform(-.025,.025)))
        v2=Vector((-sin(a)*s*.5,cos(a)*s*.5,random.uniform(-.03,.05)))
        idx=random.choices(range(5),[2,3,3,1,1])[0]; vs=leaf_vs[idx]; fs=leaf_fs[idx]; k=len(vs)
        vs.extend([tuple(p-u),tuple(p+v2),tuple(p+u),tuple(p-v2)]); fs.append((k,k+1,k+2,k+3))
def tree(x,y,h):
    z=ground(x,y); base=Vector((x,y,z)); top=base+Vector((.22,-.08,h))
    beam('Birch trunk',base,top,.12*h/5,bark,9,r2=.018)
    for k in range(15):
        zz=random.uniform(.3,h*.90); rr=.12*h/5*(1-zz/h)
        cube('Birch bark scar',(x+rr+.22*zz/h,y-.03,zz+z),(.008,.10,.025+random.random()*.03),black,0,(0,random.uniform(-.2,.2),0))
    for i in range(13):
        a=i*2.399; t=.37+i*.043
        start=base.lerp(top,t); length=h*(1-t)*random.uniform(.38,.70)
        end=start+Vector((cos(a)*length,sin(a)*length,h*.16))
        mid=start.lerp(end,.53)+Vector((0,0,.16))
        beam('Birch branch',start,mid,.037,bark,6,r2=.018); beam('Birch twig',mid,end,.018,darkwood,5,r2=.003)
        for j in range(3):
            aa=a+(j-1)*.8; tip=end+Vector((.48*cos(aa),.48*sin(aa),random.uniform(.05,.42)))
            beam('Fine twig',mid.lerp(end,.5),tip,.009,darkwood,4,r2=.001)
            leaves_at(tip,.7,80)
    leaves_at(top,.65,150)
for x,y,h in [(-6.5,3.0,5.5),(-5.9,5.6,5.0),(7.3,1.1,5.4),(6.0,6.1,5.5),(-7.8,-2.6,3.9),(8,-4.9,3.6),(-2,7,4.5)]: tree(x,y,h)
for mat,vs,fs in zip(leafm,leaf_vs,leaf_fs): mesh('Autumn leaves / '+mat.name,vs,fs,mat)

collection('11 • GROUND COVER / grasses, reeds & fallen leaves')
gvs=[[] for _ in grassm]; gfs=[[] for _ in grassm]
def grassclump(x,y,h,idx):
    z=ground(x,y)+.01; vs=gvs[idx]; fs=gfs[idx]
    for k in range(random.randint(3,6)):
        a=random.uniform(0,pi*2); w=random.uniform(.012,.024); hh=h*random.uniform(.6,1.2)
        dx,dy=random.uniform(-.07,.07),random.uniform(-.07,.07); lean=.10
        n=len(vs); vs.extend([(x+dx-w*cos(a),y+dy-w*sin(a),z),(x+dx+w*cos(a),y+dy+w*sin(a),z),(x+dx+lean*cos(a),y+dy+lean*sin(a),z+hh)])
        fs.append((n,n+1,n+2))
for i in range(8200):
    x=random.uniform(-9.8,9.8); y=random.uniform(-8,9)
    # Keep walking space, buildings, road, garden beds free of tall grass.
    if -6<x<.65 and -1.05<y<4.1: continue
    if 2.6<x<6.3 and 2.7<y<5.7: continue
    if 2.3<x<6.35 and -4.35<y<-.8: continue
    if -7.65<y<-5.3: continue
    if -1.6<x<2.5 and -5<y<1.3 and random.random()<.96: continue
    if -5.9<x<-1.6 and -3.1<y<-1.1 and random.random()<.9: continue
    grassclump(x,y,random.uniform(.11,.30),random.randrange(4))
for mat,vs,fs in zip(grassm,gvs,gfs): mesh('Dry grass / '+mat.name,vs,fs,mat)
# Fallen leaves scattered beneath trees and along the fence.
vs=[]; fs=[]
for i in range(950):
    x=random.uniform(-8.6,8.6); y=random.uniform(-5.2,7.2)
    if -5.9<x<.6 and -1<y<4: continue
    a=random.random()*pi; s=random.uniform(.025,.068); z=ground(x,y)+.022; n=len(vs)
    vs.extend([(x-s*cos(a),y-s*sin(a),z),(x-.4*s*sin(a),y+.4*s*cos(a),z+.008),(x+s*cos(a),y+s*sin(a),z),(x+.4*s*sin(a),y-.4*s*cos(a),z)])
    fs.append((n,n+1,n+2,n+3))
mesh('Fallen ochre leaves',vs,fs,leafm[1])
for i in range(100):
    x=random.uniform(-9.8,9.8); y=random.uniform(-8.8,-7.9); z=-.43
    for j in range(3):
        a=random.random()*2*pi; h=random.uniform(.4,.85)
        beam('River reed',(x,y,z),(x+.08*cos(a),y+.08*sin(a),z+h),.008,grassm[1],4,r2=.003)
        beam('Reed head',(x+.08*cos(a),y+.08*sin(a),z+h-.05),(x+.085*cos(a),y+.085*sin(a),z+h+.13),.023,darkwood,6)
# Small stepping stones from the gate to the porch.
for i in range(8):
    y=-4.55+i*.31; x=-.40-.26*sin(i*.20)
    ico('Worn stepping stone',(x,y,ground(x,y)+.025),(.22,.17,.045),stone,2)

collection('12 • LIGHTING / practical lamps & blue hour')
def lantern(x,y,z,scale=1):
    cube('Lantern lower cap',(x,y,z-.15*scale),(.26*scale,.26*scale,.055*scale),iron,.015)
    cube('Lantern glow',(x,y,z),(.13*scale,.13*scale,.23*scale),lampglass,.016)
    for dx in [-.105,.105]:
        for dy in [-.105,.105]: beam('Lantern frame',(x+dx*scale,y+dy*scale,z-.15*scale),(x+dx*scale,y+dy*scale,z+.15*scale),.012*scale,iron,5)
    bpy.ops.mesh.primitive_cone_add(vertices=4,radius1=.23*scale,radius2=.055*scale,depth=.12*scale,location=(x,y,z+.20*scale),rotation=(0,0,pi/4))
    put(bpy.context.object,'Lantern rain cap',iron)
lantern(-.74,-1.4,2.43,.65)
for x,y in [(-2.1,-5.5),(7.9,-5.8)]:
    z=ground(x,y)
    beam('Timber street lamp',(x,y,z),(x,y,3.45),.075,wood,8,r2=.05)
    curve('Iron lamp bracket',[(x,y,3.20),(x+.1,y,3.52),(x+.39,y,3.55),(x+.52,y,3.40)],.025,iron)
    lantern(x+.52,y,3.16,1)
    point('Street lantern',(x+.52,y,3.09),210,(1,.49,.17),.32)
# Overhead wire, restrained detail in the skyline.
curve('Sagging overhead wire',[(-2.1+i*.25,-5.5-i*.0075,3.4-.40*sin(i*pi/40)) for i in range(41)],.009,iron)
world=bpy.data.worlds.new('Blue hour atmosphere'); bpy.context.scene.world=world; world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.12,.20,.31,1)
world.node_tree.nodes['Background'].inputs[1].default_value=.22
def area(name,pos,target,power,color,size):
    d=bpy.data.lights.new(name,'AREA'); d.energy=power; d.color=color; d.shape='DISK'; d.size=size
    o=bpy.data.objects.new(name,d); current.objects.link(o); o.location=pos; o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
area('Cool sky / broad soft fill',(-5,-1,16),(0,0,0),800,(.48,.63,1),15)
area('Last sky glow / rim',(1,9,12),(-1,0,1),1050,(.50,.66,1),11)
# Very faint fog just above the river, no global volume hiding the modeling.
fog=bpy.data.materials.new('FOG • river haze'); fog.use_nodes=True; nn=fog.node_tree.nodes; nn.clear()
out=nn.new('ShaderNodeOutputMaterial'); vo=nn.new('ShaderNodeVolumePrincipled'); vo.inputs['Color'].default_value=(.35,.45,.57,1); vo.inputs['Density'].default_value=.025
fog.node_tree.links.new(vo.outputs['Volume'],out.inputs['Volume'])
# Mist material is left available for later art direction. No bounded fog box.

collection('13 • CAMERAS')
def camera(name,loc,target,ortho):
    d=bpy.data.cameras.new(name); o=bpy.data.objects.new(name,d); current.objects.link(o)
    o.location=loc; o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler(); d.type='ORTHO'; d.ortho_scale=ortho; d.lens=48; return o
cam=camera('01 • Courtyard / hero',(23,-32,25),(0,.1,1.15),24.6)
camera('02 • House / details',(12,-18,13),(-1.6,.7,1.6),14.5)
scene=bpy.context.scene; scene.camera=cam; scene.unit_settings.system='METRIC'; scene.unit_settings.scale_length=1
scene.render.engine='CYCLES'; scene.cycles.samples=32 if args.preview else 128; scene.cycles.use_denoising=False
scene.cycles.max_bounces=6; scene.cycles.diffuse_bounces=3; scene.cycles.glossy_bounces=3; scene.cycles.volume_bounces=0
scene.render.resolution_x=1000 if args.preview else 1600; scene.render.resolution_y=800 if args.preview else 1280; scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'; scene.render.film_transparent=False
scene.view_settings.view_transform='AgX'; scene.view_settings.look='AgX - Medium High Contrast'; scene.view_settings.exposure=.35
scene.use_nodes=True; nt=scene.node_tree; nt.nodes.clear()
rl=nt.nodes.new('CompositorNodeRLayers'); gl=nt.nodes.new('CompositorNodeGlare'); gl.glare_type='FOG_GLOW'; gl.quality='HIGH'; gl.threshold=1.6; gl.size=7; gl.mix=-.94
co=nt.nodes.new('CompositorNodeComposite'); nt.links.new(rl.outputs['Image'],gl.inputs['Image']); nt.links.new(gl.outputs['Image'],co.inputs[0])
# Open the .blend already looking through the art-directed camera.
for screen in bpy.data.screens:
    for ar in screen.areas:
        if ar.type=='VIEW_3D':
            ar.spaces.active.region_3d.view_perspective='CAMERA'
            ar.spaces.active.clip_end=400; ar.spaces.active.shading.type='MATERIAL'
            ar.spaces.active.overlay.show_overlays=False
bpy.ops.object.select_all(action='DESELECT')
scene['project_note']='Reference-inspired autumn riverside courtyard. Editable look-development scene; procedural materials, no external assets. Not a game-optimized export.'
scene['seed']=271
text=bpy.data.texts.new('READ ME / О сцене')
text.write('ДВОР У РЕКИ\nВизуальный прототип по референсу.\nBlender 4.3+, Cycles, метры.\nNum0 — камера, F12 — рендер.\nКамеры: 01 общий вид, 02 дом крупнее.\nКоллекции разделены по смыслу; все материалы процедурные.\nСцена не оптимизирована для игрового движка.\n')
scene.render.filepath=os.path.join(OUT,'courtyard_preview.png' if args.preview else 'courtyard_render.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'riverside_courtyard.blend'))
with open(os.path.join(OUT,'scene_info.json'),'w') as f:
    json.dump({'blender':bpy.app.version_string,'objects':len(scene.objects),'mesh_polygons':sum(len(o.data.polygons) for o in scene.objects if o.type=='MESH'),'materials':len(bpy.data.materials),'render':list((scene.render.resolution_x,scene.render.resolution_y)),'seed':271},f,indent=2)
bpy.ops.render.render(write_still=True)
print('COURTYARD_BUILD_COMPLETE',OUT)
