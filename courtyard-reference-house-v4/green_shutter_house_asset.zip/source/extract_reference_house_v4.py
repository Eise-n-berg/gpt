"""Create a standalone, origin-centred .blend from the comparison scene."""
import bpy,sys,json
from pathlib import Path
from mathutils import Vector
out=Path(bpy.data.filepath).parent;s=bpy.context.scene
asset=bpy.data.collections['V4 • REFERENCE HOUSE / complete asset'];keep=set(asset.all_objects)
for o in list(bpy.data.objects):
    if o not in keep:bpy.data.objects.remove(o,do_unlink=True)
for c in list(bpy.data.collections):
    if c!=asset and c not in list(asset.children):
        if not c.all_objects:bpy.data.collections.remove(c)
anchor=bpy.data.objects['NEW HOUSE • origin / ground centre'];anchor.location=(0,0,0)
for o in keep:
    if o.type=='LIGHT':o.data.energy=0
for name in ['V4 • old window glass','V4 • curtain cotton']:
    p=bpy.data.materials[name].node_tree.nodes.get('Principled BSDF');p.inputs['Emission Strength'].default_value=0
helpers=bpy.data.collections.new('REVIEW ONLY • cameras lights and ground');s.collection.children.link(helpers)
def area(name,pos,target,energy,size):
    d=bpy.data.lights.new(name,'AREA');d.energy=energy;d.shape='DISK';d.size=size
    o=bpy.data.objects.new(name,d);helpers.objects.link(o);o.location=pos;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
area('Studio • broad daylight',(-5,-6,10),(0,0,1.8),1600,7)
area('Studio • soft fill',(6,2,8),(0,0,2),1100,6)
world=bpy.data.worlds.new('Neutral studio');world.use_nodes=True;world.node_tree.nodes['Background'].inputs['Color'].default_value=(.48,.50,.52,1);world.node_tree.nodes['Background'].inputs['Strength'].default_value=.65;s.world=world
mat=bpy.data.materials.new('Studio ground');mat.diffuse_color=(.21,.22,.20,1);mat.use_nodes=True;mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=mat.diffuse_color
m=bpy.data.meshes.new('Studio ground');m.from_pydata([(-200,-200,.04),(200,-200,.04),(200,200,.04),(-200,200,.04)],[],[(0,1,2,3)]);m.materials.append(mat);o=bpy.data.objects.new('REVIEW ONLY • neutral ground',m);helpers.objects.link(o)
def camera(name,pos,target,scale):
    d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);helpers.objects.link(o);o.location=pos;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO';d.ortho_scale=scale;return o
s.camera=camera('ASSET • front and veranda',(10,-15,8),(0,.0,2.55),11.4)
camera('ASSET • rear and annex',(10,14,8),(.1,.3,2.4),11.4)
camera('ASSET • straight front',(0,-19,2.9),(0,0,2.9),10.6)
s.render.resolution_x=1440;s.render.resolution_y=1100;s.render.resolution_percentage=100;s.cycles.samples=32;s.cycles.use_denoising=False
s.view_settings.exposure=0;s.view_settings.look='AgX - Medium High Contrast'
s['asset_note']='Main house in V4 REFERENCE HOUSE collection. REVIEW ONLY collection contains display ground and studio lights. Origin at ground centre. Blender lookdev asset; not game-optimized.'
for screen in bpy.data.screens:
    for ar in screen.areas:
        if ar.type=='VIEW_3D':ar.spaces.active.region_3d.view_perspective='CAMERA'
# Remove orphaned source-house data so the standalone file contains only its materials.
bpy.ops.outliner.orphans_purge(do_recursive=True)
bpy.ops.wm.save_as_mainfile(filepath=str(out/'green_shutter_house_asset.blend'))
print('V4_STANDALONE_READY',flush=True)
if '--preview' in sys.argv:
    s.render.resolution_x=960;s.render.resolution_y=733;s.cycles.samples=16
    s.render.filepath=str(out/'daylight_preview_raw.png');bpy.ops.render.render(write_still=True)
elif '--render' in sys.argv:
    s.render.filepath=str(out/'04_asset_daylight_raw.png');bpy.ops.render.render(write_still=True)
