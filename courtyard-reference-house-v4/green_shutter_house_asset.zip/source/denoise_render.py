"""Optional render denoising for Blender builds without built-in OIDN.
Install Python dependencies with: pip install oidn numpy pillow
This is render post-processing only; the Blender scene has no dependencies.
"""
import sys, os, ctypes
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'deps'))
import oidn
import numpy as np
from PIL import Image

def denoise(src,dest):
    arr=np.asarray(Image.open(src).convert('RGB'),dtype=np.float32)/255
    arr=np.ascontiguousarray(arr); output=np.empty_like(arr); h,w=arr.shape[:2]
    lib=oidn.__lib_oidn
    threads=lib.oidnSetDevice1i; threads.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int]
    boolean=lib.oidnSetFilter1b; boolean.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_bool]
    device=oidn.NewDevice(); threads(device,b'numThreads',2); oidn.CommitDevice(device)
    f=oidn.NewFilter(device,'RT')
    oidn.SetSharedFilterImage(f,'color',arr,oidn.FORMAT_FLOAT3,w,h)
    oidn.SetSharedFilterImage(f,'output',output,oidn.FORMAT_FLOAT3,w,h)
    boolean(f,b'hdr',False); boolean(f,b'srgb',True)
    oidn.CommitFilter(f); oidn.ExecuteFilter(f)
    error=oidn.GetDeviceError(device)
    if error: raise RuntimeError('OIDN error '+str(error))
    Image.fromarray(np.clip(np.rint(output*255),0,255).astype(np.uint8)).save(dest)
    oidn.ReleaseFilter(f); oidn.ReleaseDevice(device)
    print('DENOISED',dest)

if __name__=='__main__': denoise(sys.argv[1],sys.argv[2])
