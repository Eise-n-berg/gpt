import bpy
from pathlib import Path
out=Path(bpy.data.filepath).parent;s=bpy.context.scene
s.cycles.samples=32;s.cycles.use_denoising=False;s.cycles.adaptive_threshold=.03
for name,cam,w,h in [('01_comparison','V4 • 01 / neighbouring houses',1600,1000),('02_new_front','V4 • 02 / new house front and veranda',1440,1152),('03_new_rear','V4 • 03 / new house rear and timber annex',1280,1024)]:
    s.camera=bpy.data.objects[cam];s.render.resolution_x=w;s.render.resolution_y=h;s.render.resolution_percentage=100;s.render.filepath=str(out/(name+'_raw.png'))
    bpy.ops.render.render(write_still=True);print('V4_RENDER_READY',name,flush=True)
