import bpy
from pathlib import Path
s=bpy.context.scene;out=Path(bpy.data.filepath).parent
s.camera=bpy.data.objects['ASSET • front and veranda'];s.cycles.samples=32;s.cycles.use_denoising=False
s.render.resolution_x=1440;s.render.resolution_y=1100;s.render.resolution_percentage=100
s.render.filepath=str(out/'04_asset_daylight_raw.png');bpy.ops.render.render(write_still=True)
print('V4_DAYLIGHT_READY',flush=True)
