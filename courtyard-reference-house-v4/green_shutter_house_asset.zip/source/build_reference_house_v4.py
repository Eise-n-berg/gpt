"""Build a distinct house from the user's five-view green-shutter reference.
Run on the V3 scene. No external add-ons or downloads. Unit = metre.
"""
import bpy,bmesh,math,random,os,json,sys,ast
from pathlib import Path
from mathutils import Vector
from math import sin,cos,pi
random.seed(198004)
root=Path(__file__).resolve().parent;out=root/'v4';out.mkdir(exist_ok=True)
scene=bpy.context.scene
source=ast.parse((root/'age_soviet_1980.py').read_text())
helpers={'nodeset','node','mathnode','vector','noise','ramp','mix','bump','finish'}
exec(compile(ast.Module(body=[x for x in source.body if isinstance(x,ast.FunctionDef) and x.name in helpers],type_ignores=[]),'material_helpers','exec'))
asset=bpy.data.collections.new('V4 • REFERENCE HOUSE / complete asset');scene.collection.children.link(asset)
parts={}
for label in ['01 foundation','02 log walls','03 gables','04 corrugated slate and chimney','05 carved windows and shutters','06 verandas and entrances','07 attached timber shed','08 house props']:
    c=bpy.data.collections.new('NEW HOUSE • '+label);asset.children.link(c);parts[label]=c
col=parts['01 foundation'];CX,CY=13.25,1.65
anchor=bpy.data.objects.new('NEW HOUSE • origin / ground centre',None);asset.objects.link(anchor);anchor.location=(CX,CY,0)
anchor['reference']='User supplied front, right, back, left and top elevations'
anchor['units']='metres';anchor['main_footprint_m']='6.0 x 5.8';anchor['ridge_height_m']=5.30
def mesh(name,vs,fs,mat,parent=True):
    m=bpy.data.meshes.new(name);m.from_pydata(vs,[],fs);m.update()
    if mat:m.materials.append(mat)
    o=bpy.data.objects.new('NEW • '+name,m);col.objects.link(o)
    if parent:o.parent=anchor
    return o
def cube(name,p,s,mat,bevel=0,rot=None):
    vs=[(x*s[0]/2,y*s[1]/2,z*s[2]/2) for x,y,z in [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]]
    o=mesh(name,vs,[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)],mat);o.location=p
    if rot:o.rotation_euler=rot
    if bevel:b=o.modifiers.new('Small worn arris','BEVEL');b.width=bevel;b.segments=2
    return o
def beam(name,a,b,r,mat,vertices=10,r2=None):
    d=Vector(b)-Vector(a);r2=r if r2 is None else r2
    vs=[(rr*cos(i*2*pi/vertices),rr*sin(i*2*pi/vertices),z) for rr,z in [(r,-d.length/2),(r2,d.length/2)] for i in range(vertices)]
    fs=[tuple(reversed(range(vertices))),tuple(range(vertices,2*vertices))]+[(i,(i+1)%vertices,(i+1)%vertices+vertices,i+vertices) for i in range(vertices)]
    o=mesh(name,vs,fs,mat);o.location=(Vector(a)+Vector(b))/2;o.rotation_euler=d.to_track_quat('Z','Y').to_euler();return o
def curve(name,pts,r,mat):
    c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=1
    sp=c.splines.new('POLY');sp.points.add(len(pts)-1)
    for p,v in zip(sp.points,pts):p.co=(*v,1)
    c.materials.append(mat);o=bpy.data.objects.new('NEW • '+name,c);col.objects.link(o);o.parent=anchor;return o
def ico(name,p,s,mat,sub=1):
    m=bpy.data.meshes.new(name);bm=bmesh.new();bmesh.ops.create_icosphere(bm,subdivisions=sub,radius=1);bm.to_mesh(m);bm.free();m.materials.append(mat)
    o=bpy.data.objects.new('NEW • '+name,m);col.objects.link(o);o.parent=anchor;o.location=p;o.scale=s;return o
def solid(name,c,rough=.8,metal=0):
    m,n,l,p=nodeset('V4 • '+name);p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;return m
def mapped_copy(fragment,name,tint=None):
    old=next(m for m in bpy.data.materials if m.name.startswith(fragment) and m.name.endswith('/ Z'))
    m=old.copy();m.name='V4 • '+name
    if tint:
        n=m.node_tree.nodes;l=m.node_tree.links;p=next(n for n in n if n.type=='BSDF_PRINCIPLED');old=p.inputs['Base Color'].links[0].from_socket
        l.new(mix(n,l,old,tint,mode='MULTIPLY'),p.inputs['Base Color'])
    return m
timber=mapped_copy('V3 • mapped timber / silvered','grey-brown weathered logs',(.68,.72,.69))
green=mapped_copy('V3 • mapped timber / teal','faded sage-green paint')
for n in green.node_tree.nodes:
    if n.type=='MIX_RGB' and tuple(round(x,3) for x in n.inputs[1].default_value[:3])==(.042,.115,.08):n.inputs[1].default_value=(.13,.25,.16,1)
white=mapped_copy('V3 • mapped timber / ivory','chalky white carved wood',(1.45,1.48,1.42))
for m,pigment,coverage in [(green,(.085,.235,.135),.80),(white,(.57,.61,.52),.78)]:
    n=m.node_tree.nodes;l=m.node_tree.links;p=next(x for x in n if x.type=='BSDF_PRINCIPLED')
    original=p.inputs['Base Color'].links[0].from_socket
    l.new(mix(n,l,original,pigment,coverage,label='Surviving opaque paint / less exposed timber'),p.inputs['Base Color'])
plank=mapped_copy('V3 • mapped timber / dark','unpainted annex boards',(.9,.91,.84))
endgrain=bpy.data.materials['V2 • old log ends / faded rings']
iron=next(m for m in bpy.data.materials if m.name.startswith('V3 • old hardware'))
stone=next(m for m in bpy.data.materials if m.name.startswith('STONE •'))
earth=next(m for m in bpy.data.materials if m.name.startswith('V3 • patchy earth'))
roadmat=next(m for m in bpy.data.materials if m.name.startswith('V3 • damp clay'))
dark=solid('deep window recess and chinking',(.012,.014,.011),.97)
m,n,l,p=nodeset('V4 • aged fibre-cement slate / lichen and soot')
g=node(n,'ShaderNodeNewGeometry','Slate in metres');v=g.outputs['Position']
cloud=noise(n,l,v,3,4,'Cloudy weathering');grain=noise(n,l,v,180,2,'Cement aggregate')
base=ramp(n,l,cloud,[(.2,(.08,.085,.075)),(.5,(.21,.22,.20)),(.8,(.36,.37,.32))])
l.new(mix(n,l,base,ramp(n,l,grain,[(.15,(.65,.65,.59)),(.8,(1.07,1.07,1))]),.4,mode='MULTIPLY'),p.inputs['Base Color'])
l.new(bump(n,l,grain,.0006,.4,bump(n,l,cloud,.0015,.2)),p.inputs['Normal']);p.inputs['Roughness'].default_value=.93;slate=finish(m)
brick=solid('old red clay brick',(.25,.095,.043));mortar=solid('dusty lime mortar',(.19,.18,.145))
rust=solid('rusted rain barrel',(.12,.047,.025),.85,.15)
glass=solid('old window glass',(.11,.16,.15),.22)
p=glass.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(1,.51,.21,1);p.inputs['Emission Strength'].default_value=.65
linen=solid('curtain cotton',(.43,.40,.30),.94)
p=linen.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(1,.46,.14,1);p.inputs['Emission Strength'].default_value=.36

# Foundation: irregular mortared blocks, individually modelled.
for side in [-1,1]:
    for i in range(10):
        x=-2.96+(i+.5)*.592
        for row in range(2):cube('stone plinth / front and rear',(x+(row%2)*.07,side*2.88,.23+row*.235),(.555,.28,.21),stone,.045)
    for i in range(9):
        y=-2.8+(i+.5)*5.6/9
        for row in range(2):cube('stone plinth / sides',(side*2.94,y,.23+row*.235),(.28,.58,.21),stone,.04)
cube('floor above plinth',(0,0,.52),(5.86,5.66,.12),plank)

# Actual gaps in the log courses for all doors and windows.
col=parts['02 log walls']
windows_front=[(-1.85,1.82),(0,1.82),(1.85,1.82)]
openings={
 'front':[(x-.53,x+.53,1.05,2.59) for x,z in windows_front],
 'rear':[(-.08,1.02,1.10,2.64)],
 'right':[(.50,1.60,1.10,2.64)],
 'left':[(-2.20,-1.10,.55,2.65),(.53,1.63,1.10,2.64)]}
def intervals(lo,hi,cuts):
    segments=[(lo,hi)]
    for a,b in cuts:
        segments=[p for x,y in segments for p in ([(x,min(a,y))] if x<a else [])+([(max(b,x),y)] if y>b else []) if p[1]-p[0]>.035]
    return segments
def log(name,a,b,r):
    d=Vector(b)-Vector(a);N,K=16,7;vs=[];fs=[]
    phases=[random.uniform(-.014,.014) for i in range(N)]
    for j in range(K):
        t=j/(K-1);cx=.008*sin(t*pi)*random.uniform(.6,1.0);cy=.007*sin(t*pi*2)
        for i in range(N):
            angle=2*pi*i/N;rad=r*(1+phases[i]+.016*sin(t*7+i*.7));vs.append((cx+rad*cos(angle),cy+rad*sin(angle),d.length*(t-.5)))
        if j:
            for i in range(N):fs.append(((j-1)*N+i,(j-1)*N+(i+1)%N,j*N+(i+1)%N,j*N+i))
    fs+=[tuple(reversed(range(N))),tuple((K-1)*N+i for i in range(N))]
    o=mesh(name,vs,fs,timber);o.data.materials.append(endgrain)
    for p in o.data.polygons:p.use_smooth=len(p.vertices)==4;p.material_index=int(len(p.vertices)!=4)
    o.location=(Vector(a)+Vector(b))/2;o.rotation_euler=d.to_track_quat('Z','Y').to_euler();return o
for k in range(14):
    z=.68+k*.205
    for label,side in [('front',-1),('rear',1)]:
        cuts=[(a,b) for a,b,bot,top in openings[label] if z+.12>bot and z-.12<top]
        for a,b in intervals(-3.11,3.11,cuts):
            log('cut log course / '+label,(a,side*2.9,z),(b,side*2.9,z),.119+random.uniform(-.004,.004))
            cube('chinking / '+label,((a+b)/2,side*2.9,z),((b-a),.12,.205),dark)
    for label,side in [('left',-1),('right',1)]:
        zz=z+.102;cuts=[(a,b) for a,b,bot,top in openings[label] if zz+.12>bot and zz-.12<top]
        for a,b in intervals(-3.04,3.04,cuts):
            log('notched side log / '+label,(side*3,a,zz),(side*3,b,zz),.118+random.uniform(-.003,.003))
            cube('chinking / '+label,(side*3,(a+b)/2,zz),(.12,b-a,.205),dark)

# Green vertical gables, correctly perpendicular to the old house's ridge.
col=parts['03 gables'];EAVE=3.55;RIDGE=5.30
for side in [-1,1]:
    for i in range(38):
        x=-2.96+(i+.5)*5.92/38;top=RIDGE-abs(x)*(1.75/3.18)
        if top>EAVE:cube('green gable tongue-and-groove board',(x,side*2.92,(EAVE+top)/2),(.150,.065,top-EAVE),green,.005)
    beam('gable tie beam',(-3.17,side*2.98,3.51),(3.17,side*2.98,3.51),.09,green,4)
    for sign in [-1,1]:
        beam('white bargeboard edge',(sign*3.33,side*3.12,3.49),(0,side*3.12,5.39),.042,white,4)
        beam('green bargeboard',(sign*3.27,side*3.075,3.49),(0,side*3.075,5.34),.072,green,4)
    cube('attic vent shadow',(0,side*2.97,4.56),(.22,.04,.31),dark)
    for x in [-.14,.14]:cube('attic vent surround',(x,side*3.005,4.56),(.035,.06,.38),plank)
    for z in [4.38,4.74]:cube('attic vent surround',(0,side*3.005,z),(.31,.06,.035),plank)

# Corrugated slate: waves and overlapping horizontal sheet rows are real geometry.
col=parts['04 corrugated slate and chimney']
def sheet_roof(name,xa,xb,ya,yb,za,zb,mat,rows=3):
    # Plane spans X from xa to xb and Y from ya to yb. Corrugations run along Y.
    length=abs(yb-ya);ncol=max(1,round(abs(xb-xa)/1.1))
    for row in range(rows):
        t0=row/rows;t1=min(1,(row+1)/rows+.025)
        for c in range(ncol):
            x0=xa+(xb-xa)*c/ncol;x1=xa+(xb-xa)*(c+1)/ncol
            steps=56;vs=[];fs=[]
            for j,t in enumerate([t0,(t0+t1)/2,t1]):
                for i in range(steps+1):
                    x=x0+(x1-x0)*i/steps
                    vs.append((x,ya+(yb-ya)*t,za+(zb-za)*t+.033*cos((x-xa)*2*pi/.155)+row*.009))
                if j:
                    for i in range(steps):
                        a=j*(steps+1)+i;fs.append((a-steps-1,a-steps,a+1,a))
            o=mesh(name,vs,fs,mat)
            for p in o.data.polygons:p.use_smooth=True
def main_slate(side):
    # Build from generic sheet roof then rotate 90 degrees around the ridge.
    before=set(col.objects)
    sheet_roof('overlapping corrugated slate',-3.23,3.23,0,side*3.38,RIDGE,3.45,slate,3)
    for o in set(col.objects)-before:
        for v in o.data.vertices:v.co.x,v.co.y=v.co.y,-v.co.x
for side in [-1,1]:main_slate(side)
for y in [-3.25,3.25]:beam('roof end flashing',(-3.42,y,3.43),(0,y,5.36),.045,slate,6);beam('roof end flashing',(0,y,5.36),(3.42,y,3.43),.045,slate,6)
beam('rounded slate ridge cap',(0,-3.30,5.34),(0,3.30,5.34),.10,slate,12)
for side in [-1,1]:beam('eave timber',(side*3.35,-3.28,3.41),(side*3.35,3.28,3.41),.062,plank,4)
# Individually staggered brick courses and a dark flue opening.
for row in range(13):
    z=4.42+row*.105
    cube('chimney mortar core',(.64,.2,z),(.43,.43,.104),mortar)
    for side in [-1,1]:
        for j in range(2):
            xx=.64-.21+(j+.5)*.21
            cube('chimney face brick',(xx+(row%2)*.035,.2+side*.222,z),(.195,.055,.087),brick,.005)
            cube('chimney side brick',(.64+side*.222,.2-.21+(j+.5)*.21,z),(.055,.195,.087),brick,.005)
cube('chimney coping',(.64,.2,5.80),(.53,.53,.09),brick,.012);cube('chimney open flue',(.64,.2,5.851),(.30,.30,.009),dark)

# Carved window assembly in a local front plane; depth is measured outwards.
col=parts['05 carved windows and shutters']
def face_point(center,theta,u,d,z):
    return (center[0]+u*cos(theta)+d*sin(theta),center[1]+u*sin(theta)-d*cos(theta),center[2]+z)
def face_cube(name,center,theta,u,d,z,w,depth,h,mat,b=.005):
    return cube(name,face_point(center,theta,u,d,z),(w,depth,h),mat,b,(0,0,theta))
def face_curve(name,center,theta,pts,r,mat):return curve(name,[face_point(center,theta,*p) for p in pts],r,mat)
def window(center,theta=0,shutters=True,w=.83,h=1.30):
    face_cube('window deep recess',center,theta,0,-.02,0,w+.20,.10,h+.16,dark)
    face_cube('glass behind frame',center,theta,0,.005,0,w,.016,h,glass)
    for sign in [-1,1]:
        face_cube('white window upright',center,theta,sign*(w/2+.025),.16,0,.075,.105,h+.15,white)
        # Pleated cotton curtain behind the inner sash.
        for j in range(5):
            face_cube('curtain pleat',center,theta,sign*(.21+j*.028),.04+.006*sin(j),0,.032,.013,h-.045,linen,.002)
    for z in [-h/2-.03,h/2+.03]:face_cube('white sill or lintel',center,theta,0,.17,z,w+.22,.18,.075,white)
    for u in [-w*.39,0,w*.39]:face_cube('window sash vertical',center,theta,u,.12,0,.025,.05,h,white,.002)
    face_cube('upper transom',center,theta,0,.135,h*.22,w,.055,.044,white,.002)
    face_cube('lower sash crossrail',center,theta,0,.14,-h*.18,w,.055,.03,white,.002)
    # Green casings underneath the fine white carved crown and apron.
    for sign in [-1,1]:face_cube('green carved surround',center,theta,sign*(w/2+.095),.14,0,.095,.09,h+.28,green)
    face_cube('green pediment backing',center,theta,0,.12,h/2+.16,w+.40,.10,.19,green)
    pts=[(-w*.68,.205,h/2+.20),(-w*.42,.205,h/2+.22),(-w*.22,.205,h/2+.26),(0,.205,h/2+.34),(w*.22,.205,h/2+.26),(w*.42,.205,h/2+.22),(w*.68,.205,h/2+.20)]
    face_curve('white fretwork / crown',center,theta,pts,.015,white)
    face_curve('white fretwork / crown lower edge',center,theta,[(-w*.66,.20,h/2+.17),(w*.66,.20,h/2+.17)],.012,white)
    for sign in [-1,1]:
        pts=[(sign*(.19+.10*cos(a)),.21,h/2+.23+.045*sin(a)) for a in [i*pi/10 for i in range(21)]]
        face_curve('carved scroll',center,theta,pts,.010,white)
    face_curve('white fretwork / apron',center,theta,[(u,.20,-h/2-.11-.035*cos(u*13)) for u in [-.5+i*.025 for i in range(41)]],.016,white)
    for u in [-.31,0,.31]:
        face_curve('carved pendant',center,theta,[(u-.035,.20,-h/2-.12),(u,.20,-h/2-.22),(u+.035,.20,-h/2-.12)],.012,white)
    if shutters:
        for sign in [-1,1]:
            u=sign*(w/2+.30)
            for j in range(3):face_cube('green shutter vertical board',center,theta,u+(j-1)*.105,.105,0,.10,.055,h+.055,green)
            for z in [-h*.38,h*.38]:face_cube('shutter ledge',center,theta,u,.15,z,.35,.035,.055,green)
            for z in [-h*.35,h*.35]:face_cube('black shutter strap hinge',center,theta,sign*(w/2+.16),.17,z,.16,.012,.022,iron,.002)
    # Small warm spill, matched to the existing blue-hour environment.
    d=bpy.data.lights.new('NEW • window spill','POINT');d.energy=18;d.color=(1,.59,.30);d.shadow_soft_size=.48
    o=bpy.data.objects.new(d.name,d);col.objects.link(o);o.parent=anchor;o.location=face_point(center,theta,0,.39,0)
for x,z in windows_front:window((x,-2.9,z))
window((.47,2.9,1.88),pi)
window((3,1.05,1.88),pi/2)
window((-3,1.08,1.88),-pi/2)

# Side veranda with multipane glazing and green lower cladding.
col=parts['06 verandas and entrances']
def grid_window(center,theta,w,h,cols=4,rows=3):
    face_cube('veranda glass',center,theta,0,.005,0,w,.022,h,glass)
    for i in range(cols+1):face_cube('veranda glazing bar',center,theta,-w/2+i*w/cols,.06,0,.035,.07,h+.08,white,.003)
    for i in range(rows+1):face_cube('veranda glazing bar',center,theta,0,.06,-h/2+i*h/rows,w+.08,.07,.035,white,.003)
for i in range(9):
    x=3.04+(i+.5)*1.37/9
    cube('veranda front green panelling',(x,-2.65,.85),(.144,.075,.66),green,.004)
for i in range(13):
    y=-2.62+(i+.5)*2.43/13
    cube('veranda side green panelling',(4.42,y,.85),(.075,.18,.66),green,.004)
cube('veranda plinth',(3.72,-1.43,.38),(1.58,2.65,.30),stone,.035)
for x in [3.04,4.42]:
    for y in [-2.65,-.18]:beam('veranda corner upright',(x,y,.47),(x,y,2.84),.065,green,4)
grid_window((3.73,-2.67,1.84),0,1.18,1.30,3,3)
grid_window((4.44,-1.82,1.84),pi/2,1.23,1.30,4,3)
# East-facing entrance at the rear end of the glass porch.
for i in range(5):cube('veranda entrance door board',(4.45,-.85+i*.135,1.44),(.075,.13,1.82),green,.004)
for y in [-.93,-.18]:cube('veranda door frame',(4.50,y,1.47),(.1,.075,2.02),white,.006)
cube('veranda door lintel',(4.50,-.55,2.46),(.1,.84,.075),white,.006)
beam('veranda door handle',(4.52,-.78,1.35),(4.52,-.78,1.49),.015,iron,8)
for i in range(3):cube('veranda access step',(4.70+i*.23,-.53,.40-i*.11),(.28,1.02,.13),plank,.012)
# Narrow sloped slate roof falling away from the main wall.
before=set(col.objects);sheet_roof('veranda slate',-2.82,.08,3.0,4.62,3.01,2.72,slate,2)
for o in set(col.objects)-before:
    for v in o.data.vertices:v.co.x,v.co.y=v.co.y,-v.co.x-2.77
# West-facing wooden entrance with a small rain canopy.
for i in range(7):cube('west entry door board',(-3.13,-2.12+i*.15,1.51),(.08,.142,1.88),plank,.005)
for y in [-2.22,-1.04]:cube('west door jamb',(-3.19,y,1.55),(.11,.10,2.13),green,.007)
cube('west lintel',(-3.19,-1.63,2.64),(.11,1.29,.11),green,.008)
for i in range(4):cube('west entry stair',(-3.32-i*.24,-1.64,.46-i*.095),(.30,1.28,.13),plank,.012)
cube('west entry canopy',(-3.48,-1.64,2.85),(1.08,1.60,.08),slate,.01,(0,-.17,0))
for y in [-2.25,-1.02]:beam('canopy knee brace',(-3.15,y,2.10),(-3.79,y,2.75),.035,green,4)

# Attached unpainted storage shed at the back right; clearly distinct from main logs.
col=parts['07 attached timber shed']
for i in range(12):
    y=.30+(i+.5)*2.88/12
    cube('lean-to weathered side board',(4.36,y,1.28),(.07,.23,1.98),plank,.004)
for i in range(6):
    x=3.0+(i+.5)*1.4/6
    cube('lean-to rear board',(x,3.24,1.28),(.22,.07,1.98),plank,.004)
for z in [.51,1.8]:cube('lean-to back ledge',(3.70,3.30,z),(1.45,.07,.09),timber,.006)
cube('lean-to roof',(3.71,1.73,2.54),(1.77,3.25,.075),plank,.008,(0,.22,0))
for i in range(13):cube('lean-to roof board seam',(3.71,.17+i*.25,2.59),(1.78,.015,.014),dark,0,(0,.22,0))
for row in range(4):
    for i in range(5):
        x=3.23+i*.22;z=.23+row*.20
        beam('stacked logs under lean-to',(x,.22,z),(x,.78,z),.103,plank,9)
        beam('firewood cut end',(x,.209,z),(x,.22,z),.09,endgrain,9)

col=parts['08 house props']
# Reference's simple front bench and rusting rain barrel.
for x in [-1.15,.55]:
    for y in [-3.83,-4.12]:cube('bench square leg',(x,y,.33),(.07,.07,.52),plank,.008)
for j in range(3):cube('bench slat',(-.30,-3.81-j*.15,.63),(2.08,.138,.065),plank,.008)
for x in [-1.15,.55]:beam('bench back support',(x,-3.79,.39),(x,-3.69,1.10),.035,plank,4)
for z in [.91,1.06]:cube('bench backrest',(-.3,-3.70,z),(2.08,.065,.11),plank,.008)
bx,by=4.82,-2.22
beam('rusty rain barrel',(bx,by,.13),(bx,by,.91),.29,rust,24)
for z in [.2,.54,.86]:curve('rain barrel rolled rib',[(bx+.295*cos(i*pi/20),by+.295*sin(i*pi/20),z) for i in range(41)],.012,iron)
beam('barrel dark water',(bx,by,.915),(bx,by,.922),.257,dark,24)

# Landscape expansion is separate from the reusable house collection.
land=bpy.data.collections.new('V4 • EXTENDED BANK AND SECOND YARD');scene.collection.children.link(land);col=land
def ground(x,y):return .10+.045*sin(x*1.1)*cos(y*.8)+.026*sin(x*3+y*2)
def worldmesh(name,vs,fs,mat):return mesh(name,vs,fs,mat,parent=False)
# Lift the old bank's taper at the joining edge, preserving its original left shore.
bank=bpy.data.objects['Uneven riverbank']
for v in bank.data.vertices:
    if v.co.x>9.10:
        x,y=v.co.x,v.co.y;front=-8.4+.48*sin(x*.55)+.20*sin(x*1.8);vv=(y-front)/(9.4-front)
        edge=min((x+10)/20,vv,1-vv);z=ground(x,y)
        if edge<.045:z-=.7*(1-edge/.045)
        if vv<.07:z-=.22*(1-vv/.07)
        v.co.z=z
N,M=58,92;vs=[];fs=[]
for j in range(M+1):
    vv=j/M
    for i in range(N+1):
        x=10+10.2*i/N;front=-8.4+.48*sin(x*.55)+.20*sin(x*1.8);y=front+(9.4-front)*vv
        z=ground(x,y)
        edge=min((20.2-x)/10.2,vv,1-vv)
        if edge<.045:z-=.7*(1-edge/.045)
        if vv<.07:z-=.22*(1-vv/.07)
        vs.append((x,y,z))
for j in range(M):
    for i in range(N):
        a=j*(N+1)+i;center=sum((vs[k][1] for k in [a,a+1,a+N+2,a+N+1]))/4
        x=vs[a][0];cy=-6.4+.33*sin(x*.3)
        if abs(center-cy)>.84:fs.append((a,a+1,a+N+2,a+N+1))
worldmesh('extended riverbank / second parcel',vs,fs,earth)
vs=[];fs=[]
for i in range(48):
    x=10.9+i*.2;cy=-6.4+.33*sin(x*.3)
    for j in range(25):
        dy=-1+j/12;rut=.034*sum(math.exp(-((dy-v)/.085)**2) for v in [-.57,.57]);vs.append((x,cy+dy,ground(x,cy+dy)+.046-rut))
    if i:
        for j in range(24):a=i*25+j;fs.append((a-25,a,a+1,a-24))
worldmesh('continued dirt lane',vs,fs,roadmat)
# Landscape helpers use absolute coordinates rather than the asset origin.
def wcube(name,p,s,mat,bevel=0,rot=None):
    o=cube(name,p,s,mat,bevel,rot);o.parent=None;return o
def wbeam(name,a,b,r,mat,vertices=8):
    o=beam(name,a,b,r,mat,vertices);o.parent=None;return o
def wico(name,p,s,mat,sub=1):
    o=ico(name,p,s,mat,sub);o.parent=None;return o
for i in range(64):
    x=random.uniform(10.2,20);y=-8.25+.48*sin(x*.55)+random.uniform(-.4,.12);r=random.uniform(.12,.4)
    wico('second shore / stones',(x,y,-.2),(r,r*.75,r*.63),stone)
def fence(a,b):
    a=Vector((*a,0));b=Vector((*b,0));d=b-a;length=d.length;n=round(length/.245);theta=math.atan2(d.y,d.x)
    for i in range(n+1):
        p=a+d*i/n;h=random.uniform(.86,1.02);z=ground(p.x,p.y)
        o=wcube('new yard grey-green picket',(p.x,p.y,z+h/2),(.10,.045,h),green,.012,(0,random.uniform(-.035,.035),theta))
    for h in [.30,.69]:wbeam('new yard fence rail',(a.x,a.y,ground(a.x,a.y)+h),(b.x,b.y,ground(b.x,b.y)+h),.038,timber,4)
    for i in range(round(length/1.8)+1):
        t=i/max(1,round(length/1.8));p=a+d*t;wbeam('new yard fence post',(p.x,p.y,.1),(p.x,p.y,1.19),.06,plank,6)
fence((8.5,-4.85),(14.9,-4.85));fence((16.3,-4.85),(19,-4.85));fence((19,-4.85),(19,6.3));fence((8.5,6.3),(19,6.3))
# A restrained path from the gate to the veranda steps.
for i in range(15):
    t=i/14;x=15.6+2.9*t;y=-4.75+5.5*t
    wico('new yard stepping stone',(x,y,.15),(random.uniform(.18,.27),.22,.045),stone,1)
# Small bushes as thin branching stems and irregular leaves, not solid blobs.
leafm=[m for m in bpy.data.materials if m.name.startswith('LEAF •')];grassm=[m for m in bpy.data.materials if m.name.startswith('GRASS •')]
def bush(x,y,size):
    for j in range(12):
        a=random.random()*2*pi;r=random.uniform(.2,.65)*size;h=random.uniform(.3,1.2)*size
        end=(x+r*cos(a),y+r*sin(a),h+.1);wbeam('autumn shrub stem',(x,y,.1),end,.008,plank,5)
        vs=[];fs=[]
        for k in range(24):
            t=random.uniform(.35,1);p=Vector((x+(end[0]-x)*t,y+(end[1]-y)*t,.1+h*t))+Vector((random.uniform(-.17,.17),random.uniform(-.17,.17),random.uniform(-.08,.08)))
            w=random.uniform(.025,.055);idx=len(vs);vs.extend([tuple(p+Vector((-w,0,0))),tuple(p+Vector((0,-w*.6,.006))),tuple(p+Vector((w,0,0))),tuple(p+Vector((0,w*.6,.018)))]);fs.append((idx,idx+1,idx+2,idx+3))
        worldmesh('yellow shrub leaves',vs,fs,random.choice(leafm))
for x,y,sz in [(10.0,-1.8,1.15),(16.3,-1.6,.65),(10.0,5.1,1.25),(17.7,5.5,1.2),(12.2,-2.9,.55),(18.5,-3.8,.7)]:bush(x,y,sz)
for mat in grassm:
    vs=[];fs=[]
    for i in range(260):
        x=random.uniform(8.6,19);y=random.uniform(-4.6,6.2)
        if 10.0<x<17.9 and -1.3<y<4.8:continue
        if 11.5<x<14.1 and -2.7<y<-1.2:continue
        z=ground(x,y);h=random.uniform(.08,.25);w=.012;k=len(vs)
        vs.extend([(x-w,y,z),(x+w,y,z),(x+.07,y+.025,z+h),(x,y+.05,z+h*.85)]);fs.append((k,k+1,k+2,k+3))
    worldmesh('new yard fine grass',vs,fs,mat)

# One matching practical street light for the neighbouring parcel.
wbeam('new lane electric pole',(14.7,-5.45,.05),(14.7,-5.45,3.45),.072,plank,10)
wbeam('new pole lamp arm',(14.7,-5.45,3.35),(15.23,-5.45,3.28),.027,iron,8)
o=beam('new lane reflector',(15.23,-5.45,3.21),(15.23,-5.45,3.34),.19,white,24,r2=.035);o.parent=None
d=bpy.data.lights.new('V4 • second yard street lamp','POINT');d.energy=210;d.color=(1,.49,.17);d.shadow_soft_size=.32;o=bpy.data.objects.new(d.name,d);land.objects.link(o);o.location=(15.23,-5.45,3.11)
# Match ambient fill coverage on both houses without changing original practicals.
d=bpy.data.lights.new('V4 • broad cool sky extension','AREA');d.energy=700;d.color=(.53,.68,1);d.shape='DISK';d.size=13
o=bpy.data.objects.new(d.name,d);land.objects.link(o);o.location=(15,-1,12);o.rotation_euler=(Vector((13,1,1))-o.location).to_track_quat('-Z','Y').to_euler()

def camera(name,loc,target,scale):
    d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO';d.ortho_scale=scale;return o
camera('V4 • 01 / neighbouring houses',(23,-36,24),(5.3,.2,1.6),32.8)
camera('V4 • 02 / new house front and veranda',(26,-18,13),(13.7,1.1,2.3),12.2)
camera('V4 • 03 / new house rear and timber annex',(24,18,11),(13.8,2.0,2.25),11.9)
camera('V4 • 04 / reference front',(13.25,-19,5.2),(13.25,.4,2.5),10.4)
scene.camera=bpy.data.objects['V4 • 01 / neighbouring houses']
scene.cycles.use_denoising=False;scene.cycles.samples=48;scene.cycles.adaptive_threshold=.025
scene.render.resolution_x=1600;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
scene['version']='V4 / new green-shutter reference house beside the V3 courtyard'
scene['new_asset_collection']=asset.name
scene['new_asset_origin']='13.25, 1.65, 0 metres'
bpy.ops.wm.save_as_mainfile(filepath=str(out/'two_houses_comparison_v4.blend'))
info={'objects_total':len(scene.objects),'asset_objects':len(asset.all_objects),'asset_mesh_polygons':sum(len(o.data.polygons) for o in asset.all_objects if o.type=='MESH'),'main_footprint_m':[6,5.8],'ridge_height_m':5.30,'asset_collection':asset.name}
(out/'scene_info.json').write_text(json.dumps(info,indent=2));print('V4_BUILD_READY',json.dumps(info),flush=True)
if '--preview' in sys.argv:
    scene.camera=bpy.data.objects['V4 • 01 / neighbouring houses' if '--compare' in sys.argv else 'V4 • 02 / new house front and veranda'];scene.render.resolution_x=1000;scene.render.resolution_y=625 if '--compare' in sys.argv else 800;scene.cycles.samples=16
    scene.render.filepath=str(out/'preview_raw.png');bpy.ops.render.render(write_still=True)
