import bpy
from pathlib import Path
s=bpy.context.scene;out=Path(bpy.data.filepath).parent
s.render.resolution_percentage=100
s.cycles.adaptive_threshold=.02;s.cycles.use_denoising=False
for name,camera in [('01_overview','01 • Courtyard / hero'),('02_facade','V2 • Facade and age detail'),('03_materials','V3 • Material closeup')]:
    s.render.resolution_x=1600 if name=='02_facade' else 1440
    s.render.resolution_y=int(s.render.resolution_x*.8)
    s.cycles.samples=32 if name=='01_overview' else 48
    s.camera=bpy.data.objects[camera];s.render.filepath=str(out/(name+'_raw.png'))
    bpy.ops.render.render(write_still=True)
    print('V3_RENDER_READY',name,flush=True)
