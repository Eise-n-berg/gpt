"""Run outside Blender to avoid native denoiser library conflicts.
Keep a small portion of the converged render's high-frequency texture signal.
"""
from pathlib import Path
import time,sys
import numpy as np
from PIL import Image
root=Path(__file__).resolve().parent;out=root/'v3';sys.path.insert(0,str(root))
from denoise_render import denoise
for name in ['01_overview','02_facade','03_materials']:
    raw=out/(name+'_raw.png')
    while not raw.exists():time.sleep(2)
    time.sleep(2)
    clean=out/(name+'_denoised.png');dest=out/(name+'.png')
    denoise(str(raw),str(clean))
    a=np.asarray(Image.open(raw).convert('RGB'),dtype=np.float32)
    b=np.asarray(Image.open(clean).convert('RGB'),dtype=np.float32)
    # Conservative blend: predominantly denoised, with slight residual fine grain.
    Image.fromarray(np.uint8(np.clip(.12*a+.88*b,0,255))).save(dest)
    print('V3_FINAL_READY',name,flush=True)
