"""Original, deterministic timber maps; no third-party source imagery.
4m x 0.65m tile, 4096 x 1024 pixels. Longitudinal grain runs along U.
Run with normal Python (numpy, scipy, Pillow), before Blender's V3 pass.
"""
from pathlib import Path
import numpy as np
from scipy.ndimage import gaussian_filter, zoom
from PIL import Image

out=Path(__file__).resolve().parent/'v3'/'textures';out.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(198003)
H,W=1024,4096
u=np.arange(W,dtype=np.float32)[None,:]/W
v=np.arange(H,dtype=np.float32)[:,None]/H
def field(h,w):
    a=rng.random((h,w),dtype=np.float32)
    a=zoom(a,(H/h,W/w),order=3,mode='wrap')[:H,:W]
    return a
cloud=field(16,24);long=field(280,24);fine=field(700,180)
phase=v*151+2.7*field(80,8)+.5*np.sin(u*24+v*13)
# Grain flows around small knots instead of consisting of stretched noise alone.
knots=np.zeros((H,W),dtype=np.float32)
for i in range(11):
    x,y=rng.uniform(.04,.96,2); rx=rng.uniform(.008,.022);ry=rng.uniform(.012,.027)
    dx=(u-x)/rx;dy=(v-y)/ry
    env=np.exp(-(.11*dx**2+.22*dy**2))
    phase+=env*dy*2.3
    knots=np.maximum(knots,np.exp(-(.9*dx**2+.95*dy**2)))
rings=(.5+.5*np.cos(phase*2*np.pi))**12
splits=np.clip((.29-field(600,18))*9,0,1)*np.clip((field(60,36)-.32)*3,0,1)
hair=np.clip((.24-field(900,48))*6,0,.7)
grain=.56+.27*(long-.5)+.18*(cloud-.5)-.23*rings-.28*splits-.11*hair-.25*knots
grain+=rng.normal(0,.011,(H,W)).astype(np.float32)
grain=np.clip(grain,.07,.85)
# sRGB values: desaturated grey-brown weathered pine, bleached streaks and checks.
rgb=np.stack([grain*.83+.035,grain*.79+.035,grain*.66+.04],axis=-1)
Image.fromarray(np.uint8(np.clip(rgb,0,1)*255)).save(out/'timber_basecolor_4k.png')
height=np.clip(.52+.11*long-.12*rings-.38*splits-.15*hair-.13*knots+.025*fine,0,1)
Image.fromarray(np.uint8(height*255)).save(out/'timber_height_4k.png')
rough=np.clip(.74+.15*(1-grain)+.08*splits-.06*cloud,.58,.98)
Image.fromarray(np.uint8(rough*255)).save(out/'timber_roughness_4k.png')
flake=.59*field(260,34)+.25*field(44,30)+.16*field(800,240)
paint=np.clip((flake-.425)*18+.25,0,1)*(1-.8*splits)
Image.fromarray(np.uint8(paint*255)).save(out/'timber_paint_mask_4k.png')
print('V3: four original 4096 x 1024 material maps generated',flush=True)
