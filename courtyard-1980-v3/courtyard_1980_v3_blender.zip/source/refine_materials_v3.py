"""Load V2 blend, install mapped timber and layered metal/soil, pack textures.
Run: blender -b v2/riverside_courtyard_1980_v2.blend -t 3 --python refine_materials_v3.py
"""
import bpy,ast,os,sys,math,json
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parent;out=root/'v3';out.mkdir(exist_ok=True)
s=bpy.context.scene
# Share only the small material helpers, without executing V2 scene construction.
names={'nodeset','node','mathnode','vector','noise','ramp','mix','bump','finish','local_axis'}
source=ast.parse((root/'age_soviet_1980.py').read_text())
exec(compile(ast.Module(body=[x for x in source.body if isinstance(x,ast.FunctionDef) and x.name in names],type_ignores=[]),'v2_material_helpers','exec'))
maps={}
for kind,file in [('color','timber_basecolor_4k.png'),('height','timber_height_4k.png'),('rough','timber_roughness_4k.png'),('paint','timber_paint_mask_4k.png')]:
    im=bpy.data.images.load(str(out/'textures'/file));im.name='V3 / '+file
    if kind!='color':im.colorspace_settings.name='Non-Color'
    im.pack();maps[kind]=im

def timber(axis,paint=None,dark=False):
    label=paint or ('dark' if dark else 'silvered')
    m,n,l,p=nodeset('V3 • mapped timber / '+label+' / '+axis)
    tc=node(n,'ShaderNodeTexCoord','Local coordinates / metres');sp=node(n,'ShaderNodeSeparateXYZ','Grain direction');l.new(tc.outputs['Object'],sp.inputs[0])
    info=node(n,'ShaderNodeObjectInfo','Unique offset per board')
    a='XYZ'.index(axis);others=[i for i in range(3) if i!=a]
    uv=node(n,'ShaderNodeCombineXYZ','4m x 0.65m timber strip')
    u=mathnode(n,l,'ADD',mathnode(n,l,'MULTIPLY',sp.outputs[a],.25),info.outputs['Random'])
    v=mathnode(n,l,'ADD',mathnode(n,l,'MULTIPLY',mathnode(n,l,'ADD',sp.outputs[others[0]],sp.outputs[others[1]]),1.54),mathnode(n,l,'MULTIPLY',info.outputs['Random'],3.73))
    l.new(u,uv.inputs['X']);l.new(v,uv.inputs['Y'])
    tex={}
    for kind,im in maps.items():
        t=node(n,'ShaderNodeTexImage',kind+' / 4096 px / packed');t.image=im;t.extension='REPEAT';t.interpolation='Linear';l.new(uv.outputs[0],t.inputs[0]);tex[kind]=t.outputs['Color']
    variation=ramp(n,l,info.outputs['Random'],[(0,(.67,.65,.59)),(1,(1.05,1.05,.99))])
    base=mix(n,l,tex['color'],variation,mode='MULTIPLY')
    geom=node(n,'ShaderNodeNewGeometry','Shared weather exposure')
    stain=noise(n,l,vector(n,l,geom.outputs['Position'],(2,2,.38)),1,3,'Rain streaks')
    stain=ramp(n,l,stain,[(.2,(.40,.44,.35)),(.75,(1,1,1))])
    base=mix(n,l,base,stain,fac=.44,mode='MULTIPLY')
    normal=bump(n,l,tex['height'],.0065,.55)
    if paint:
        pigment=(.042,.115,.080) if paint=='teal' else (.31,.33,.255)
        pigment=mix(n,l,pigment,ramp(n,l,tex['color'],[(.15,(.48,.48,.44)),(.60,(1,1,.95))]),mode='MULTIPLY')
        base=mix(n,l,base,pigment,tex['paint'],label='Faded paint and exposed grain')
        normal=bump(n,l,tex['paint'],.0008,.7,normal)
    if dark:base=mix(n,l,base,(.47,.49,.43),mode='MULTIPLY')
    l.new(base,p.inputs['Base Color']);l.new(tex['rough'],p.inputs['Roughness']);l.new(normal,p.inputs['Normal'])
    return finish(m)

cache={}
for o in s.objects:
    if o.type not in {'MESH','CURVE'}:continue
    axis=local_axis(o)
    for slot in o.material_slots:
        if not slot.material:continue
        name=slot.material.name
        category=None
        if name.startswith('V2 • silvered timber'):category='silvered'
        elif name.startswith('V2 • dark timber'):category='dark'
        elif name.startswith('V2 • old ivory paint'):category='ivory'
        elif name.startswith('V2 • teal paint'):category='teal'
        if category:
            key=(category,axis)
            if key not in cache:cache[key]=timber(axis,paint=category if category in {'ivory','teal'} else None,dark=category=='dark')
            slot.material=cache[key]

# Keep macro weathering from V2, add galvanised crystal structure and fine oxide.
for m in list(bpy.data.materials):
    if not m.name.startswith(('V2 • oxidised roof','V2 • old hardware')):continue
    m.name=m.name.replace('V2','V3',1);n=m.node_tree.nodes;l=m.node_tree.links;p=next(x for x in n if x.type=='BSDF_PRINCIPLED')
    geom=node(n,'ShaderNodeNewGeometry','Fine metal in world metres');v=geom.outputs['Position']
    vo=node(n,'ShaderNodeTexVoronoi','Weathered zinc crystals / 4mm');vo.inputs['Scale'].default_value=240;l.new(v,vo.inputs['Vector'])
    contrast=ramp(n,l,vo.outputs['Distance'],[(.1,(.56,.59,.59)),(.8,(1.12,1.12,1.08))])
    old=p.inputs['Base Color'].links[0].from_socket;l.new(mix(n,l,old,contrast,.5,mode='MULTIPLY'),p.inputs['Base Color'])
    rain=noise(n,l,vector(n,l,v,(17,17,1.4)),1,3,'Fine runoff streaks')
    oldnorm=p.inputs['Normal'].links[0].from_socket
    normal=bump(n,l,rain,.0025,.5,oldnorm)
    l.new(bump(n,l,vo.outputs['Distance'],.0005,.45,normal),p.inputs['Normal'])
    # A mid-scale mottled patina catches the broad cool light.
    patina=noise(n,l,v,35,3,'Mottled oxide between seams')
    rough=ramp(n,l,patina,[(.2,(.49,.49,.49)),(.8,(.91,.91,.91))]);l.new(rough,p.inputs['Roughness'])
    finish(m)

for m in list(bpy.data.materials):
    if not m.name.startswith(('V2 • patchy earth','V2 • damp clay','V2 • garden humus')):continue
    m.name=m.name.replace('V2','V3',1);n=m.node_tree.nodes;l=m.node_tree.links;p=next(x for x in n if x.type=='BSDF_PRINCIPLED')
    g=node(n,'ShaderNodeNewGeometry','Gravel and clay in metres');v=g.outputs['Position']
    vo=node(n,'ShaderNodeTexVoronoi','Scattered grit / 8-12mm');vo.inputs['Scale'].default_value=95;l.new(v,vo.inputs['Vector'])
    grains=ramp(n,l,vo.outputs['Distance'],[(.05,(.42,.39,.32)),(.20,(.81,.77,.65)),(.42,(1,1,.95))])
    old=p.inputs['Base Color'].links[0].from_socket;l.new(mix(n,l,old,grains,.65,mode='MULTIPLY'),p.inputs['Base Color'])
    oldnormal=p.inputs['Normal'].links[0].from_socket
    l.new(bump(n,l,vo.outputs['Distance'],.008,.7,oldnormal),p.inputs['Normal']);finish(m)

# A comparison frame uses the identical V2 facade camera. A second camera resolves grain.
data=bpy.data.cameras.new('V3 • Material closeup');cam=bpy.data.objects.new(data.name,data);s.collection.objects.link(cam)
cam.location=(1.8,-10.5,5.8);cam.rotation_euler=(Vector((-2.75,-.6,1.85))-cam.location).to_track_quat('-Z','Y').to_euler();data.type='ORTHO';data.ortho_scale=5.5
s.camera=bpy.data.objects['01 • Courtyard / hero'];s.cycles.samples=96;s.cycles.use_denoising=False
s.cycles.adaptive_threshold=.015;s.render.resolution_x=1600;s.render.resolution_y=1280;s.render.resolution_percentage=100
s['version']='V3 / high resolution mapped timber and multiscale metal and soil'
s['texture_note']='Four original 4096x1024 maps, packed in blend; procedural metal and soil. Not photogrammetry.'
s.render.filepath=str(out/'01_overview_raw.png')
bpy.ops.wm.save_as_mainfile(filepath=str(out/'riverside_courtyard_1980_v3.blend'))
print('V3_SCENE_READY',flush=True)
if '--preview' in sys.argv:
    s.camera=bpy.data.objects['V2 • Facade and age detail'];s.render.resolution_x=1000;s.render.resolution_y=800;s.cycles.samples=32
    s.render.filepath=str(out/'preview_raw.png');bpy.ops.render.render(write_still=True)
